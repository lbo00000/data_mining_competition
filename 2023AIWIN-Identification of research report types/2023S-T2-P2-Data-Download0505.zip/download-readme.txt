## 正式榜单
数据大小约2G，提供在ZIP压缩包形式下，解压后含有两个文件夹
- train_dataset 含有所有训练集的研报PDF（首页），且按照其对应label分类组织至子文件夹中
- eval_dataset 含有测试集的所有研报PDF（首页），PDF文件的文件名为UID

0505版本较原版本去除了如下破损内容：
训练集：
个股研报-new
6038686-new.pdf
6036182-new.pdf
6045132-new.pdf
6038657-new.pdf
6038698-new.pdf
6048795-new.pdf
其他研报-new
08934d08226948e4a3399cec153b0227-new.pdf

测试集:
['968e595d06cc599e8603ac213a7bdfdb',
 '5e9804e922f654a7b4eb37222649d3d4',
 '9c7ce415fa9955d491209bbe5951d553',
 '495f28b2c97f5281adfb9680dd65a19d']

## 下载地址：

### 百度网盘 0505版本
链接: https://pan.baidu.com/s/1Udv39MpFb2TFFu3JlX3Tsg?pwd=y9ut
提取码: y9ut 


### 阿里云盘 （链接不变，已更新完为0505内容）
训练集：
https://www.aliyundrive.com/s/GTRrg5GNREf

测试集:
https://www.aliyundrive.com/s/km1aRrq7gRW


### Google Driver 0505 更新链接
https://drive.google.com/file/d/1jVXBWOXCvKkJsXkDlUS6asIEY9gUme07/view?usp=sharing
