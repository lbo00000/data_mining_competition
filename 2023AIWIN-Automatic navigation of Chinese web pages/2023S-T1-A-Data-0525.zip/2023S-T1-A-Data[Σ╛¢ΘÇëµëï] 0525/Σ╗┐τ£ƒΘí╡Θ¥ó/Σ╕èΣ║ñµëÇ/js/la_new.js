try
{	
	var _$CVersion = '20170109';
	var _Sauthor;
	var _Scount_iframe;
	var _Sload_time;
	var _Spage_type;
	var _Spage_pic;
	var _Spage_id;
	var _$Cformlist = '';
	var _$Cformdetails = {};
	var _$Cformfielddetails = {};
	var _$Cwebsite = _$Cpartner_website=_$Mwebsite || '';
	var _Spartner_website_id;
	var _Schannel_website_id;
	var _Schannel_webshop_id;
	var _Spageformjs = false;
	var _Sorder_encode_url;
	var _$Cchkdomain = '';
	if (_Scount_iframe === true)
	{
		var _$Cdocument = top.window.document;
	}
	else
	{
		var _$Cdocument = window.document;
	}
	var _$Cdocumentbody = _$Cdocument.getElementsByTagName('body')[0];
	var _$Cprotocol = _$Cdocument.location.protocol;
	var _trackDataType;
	var _trackData = _trackData || [];
	var _$Ciserror = 0;
	var _$Cerrorcode = '';
	var _$Cflashid = 'yfx_n_r_u';
	var _$Ccounturl = '//replay.sseinfo.com/phpstat';
	var _$Ccounturl_proxy = '//sia.sseinfo.com';
	
	var _$Cmediumsource = _$Cmediumsourcefirst = _$Ckeywordsource = _$Cedmemail = _$Ckeywordkey = '';
	var _$Cstarttime = _$Ctimestart = _$Cloadtime = _$Cdowntime = _$Cgettime = (new Date()).getTime();
	
	function _$Cunicode(s){
	   var len=s.length;
	   var rs=0;
	   for(var i=0;i<len;i++){
			  rs+= parseInt(s.charCodeAt(i)%10);
	   }
	   return rs;
	}
	function _$Creadmapcookie(name)
	{
		var cV = end = '';
		var v = name + '=';
		if (_$Cdocument.cookie) 
		{
			var p = _$Cdocument.cookie.indexOf(v);
			if (p > -1) {
				p += v.length;
				end = _$Cdocument.cookie.indexOf(";", p);
				if (end == -1) {end = _$Cdocument.cookie.length;};
				cV = _$Cdocument.cookie.substring(p, end);
			}
			return cV;
		}
	}
	function _$Csplitdomain(gethost)
	{
		var pattern = new Array();
		var domain  = '';
		var isdomain  = 0;
		var domainlen = 0;
		pattern['.com.cn']	= 4;
		pattern['.net.cn']	= 4;
		pattern['.gov.cn']	= 4;
		pattern['.org.cn']	= 4;
		pattern['.com']	= 3;
		pattern['.net']	= 3;
		pattern['.org']	= 3;
		pattern['.gov']	= 3;
		pattern['.cc']	= 3;
		pattern['.biz']	= 3;
		pattern['.info']= 3;
		pattern['.cn']	= 3;
		pattern['.hk']	= 3;			
		for( var dk in pattern )
		{
			if( gethost.indexOf(dk) > -1 )
			{
				isdomain = 1;
				domainlen = parseInt(pattern[dk]);
				break;
			}
		}
		if( isdomain == 1 )
		{
			var s = gethost.split('.');
			if( s.length >= (domainlen) )
			{
				s[0] = '';
				domain = (s.join('.')).substr(1);
			}
			else
			{
				domain = gethost;
			}
		}
		else
		{
			domain = gethost;
		}
		return domain;
	}
	function _$Cgetservercookie(ghostvar,gtype)
	{
		var _$Curl = _$Ccounturl + '/getcookie.js.php';
		var _$Cobj = _$Cdocument.createElement('script');
		_$Cobj.type = 'text/javascript';
		_$Cobj.async = true;
		_$Cobj.id = 'getcookie_id';
		_$Cobj.charset = 'utf-8';
		var _$Cdurl = _$Curl + '?website=' + _$Cwebsite + '&prefix=_$C&jsprefix=yfx_&domain=' + ghostvar + '&type=' + gtype + '&rand=' + Math.random();
		_$Cdocument.getElementsByTagName('head').item(0).appendChild(_$Cobj);
		_$Cdocument.getElementById('getcookie_id').src = _$Cdurl;
	}
	(function() {
		var CHARS = '01234567891357924680'.split('');
		Math.uuid = function (len, radix) 
		{
			var chars = CHARS, uuid = [], i;
			radix = radix || chars.length;

			if (len)
			{
				for (i = 0; i < len; i++) uuid[i] = chars[0 | (Math.random()*radix)];
			}
			return uuid.join('');
		};
	})();
	function _$Cflash_cookie()
	{
		var f=0;
		var v=0;
		var swf;
		var ie = _$Cuseragent.match(/msie ([\d.]+)/);
		if(ie)
		{
			try {
			swf = new ActiveXObject('ShockwaveFlash.ShockwaveFlash');
			if(swf) 
			{
				f=1;
				var vs=swf.GetVariable("$version");
				v=parseInt(vs.split(" ")[1].split(",")[0]);
			}
			}
			catch (e) {
			}
		}
		else
		{
			if (navigator.plugins && navigator.plugins.length > 0)
			{
				swf=navigator.plugins["Shockwave Flash"];
				if (swf)
				{
					f=1;
					var ws = swf.description.split(" ");
					for (var i = 0; i < ws.length; ++i)
					{
						if (isNaN(parseInt(ws[i]))) continue;
						v = parseInt(ws[i]);
					}
				}
			}
		}
		return {f:f,v:v};
	}	
	var _$Crandomid = _$Cstarttime+''+Math.uuid(3,5);
	var _$Cuseragent = navigator.userAgent.toLowerCase();
	var _$Ctelphone = /(nokia|sony|ericsson|moto|samsung|htc|sgh|lg|sharp|philips|panasonic|alcatel|lenovo|iphone|ipod|ipad|blackberry|meizu|android|netfront|symbian|ucweb|windowsce|palm|operamini|openwave|nexusone|playstation|nintendo|symbianos|dangerhiptop|dopod|midp)/.exec(_$Cuseragent);
	_$Ctelphone = _$Ctelphone === null ? '' : _$Ctelphone[0];
	var _$Cflashok = _$Cflash_cookie();
	var _$Cphpstat_flash_object;
	function _$Cdownloadflash(){

		"use strict";
		var counter = 0;	
		var alpnum = /[^a-z0-9_]/ig;

		window.phpstatCookie = function(config){
			config = config || {};
			var defaults = {
				swf_url: _$Ccounturl_proxy+'/cookie/storage.swf',
				namespace: 'namespace_phpstat',
				debug: true,
				timeout: 10,
				onready: null,
				onerror: null
			};
			var key;
			for(key in defaults){
				if(defaults.hasOwnProperty(key)){
					if(!config.hasOwnProperty(key)){
						config[key] = defaults[key];
					}
				}
			}
			function _$Cdiv(visible){
				var d = _$Cdocument.createElement('div');
					d.id = "sseinfo_js_div_id_10000001";
				var s = (_$Cfgid('sseinfo_js_id_10000001')||_$Cfgid('sseinfo_js_id')); 
				if (s)
				{				
					d.async = true; 
					s.parentNode.insertBefore(d, s);
				}
				return d;
			}
			var swfContainer = _$Cdiv(config.debug);
			config.namespace = config.namespace.replace(alpnum, '_');
			this.config = config;		
			function _$Cfid(){
				return "phpstatCookie_" + config.namespace + "_" +  (counter++);
			}
			function _$Cfgid(id){
				return _$Cdocument.getElementById(id);
			}
			phpstatCookie[config.namespace] = this;
			
			var swfName = _$Cfid();
				
			var flashvars = "logfn=phpstatCookie." + config.namespace + ".log&amp;" + 
				"onload=phpstatCookie." + config.namespace + ".onload&amp;" + 
				"onerror=phpstatCookie." + config.namespace + ".onerror&amp;" + 
				"LSOName=" + config.namespace;
				
			swfContainer.innerHTML = '<object height="1" width="1" codebase="//download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab" id="' + 
				swfName + '" classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000">' +
				'	<param value="' + config.swf_url + '" name="movie">' + 
				'	<param value="' + flashvars + '" name="FlashVars">' +
				'	<param value="always" name="allowScriptAccess">' +
				'	<embed height="1" align="middle" width="1" pluginspage="//www.macromedia.com/go/getflashplayer" ' +
				'flashvars="' + flashvars + '" type="application/x-shockwave-flash" allowscriptaccess="always" quality="high" loop="false" play="true" ' +
				'name="' + swfName + '" bgcolor="#ffffff" src="' + config.swf_url + '">' +
				'</object>';
			
			this.swf = _$Cdocument[swfName] || window[swfName];
			
			this._timeout = setTimeout(function(){
				if(config.onerror){
					config.onerror();
				}
			}, config.timeout * 1000);
		};

		phpstatCookie.prototype = {
	  
			version: "1.5",
			ready: false,
			set: function(key, value){
				this._checkReady();
				this.swf.set(key, value);
			},
			get: function(key){
				this._checkReady();
				return this.swf.get(key);
			},
			getAll: function(){
				this._checkReady();
				var data = this.swf.getAll();
				if(data.__flashBugFix){
					delete data.__flashBugFix;
				}
				return data;
			},
			clear: function(key){
				this._checkReady();
				this.swf.clear(key);
			},
			_checkReady: function(){
			},
			"onload": function(){
				var that = this;
				setTimeout(function(){
				  clearTimeout(that._timeout);
				  that.ready = true;
				  that.set('__flashBugFix','1');
				  if(that.config.onready){
					that.config.onready();
				  }
				}, 0);
			},
			onerror: function(){
				clearTimeout(this._timeout);
				if(this.config.onerror){
					this.config.onerror();
				}
			}
			
		};
	}
	var _$Cisdownloadflash = 0;
	if(_$Cflashok.v >= 88 && _$Cdocument.location.hash.toString().indexOf('clickmapcode') <= -1 && typeof(_$Cdocumentbody) !== 'undefined' && _$Ctelphone === '' && _$Creadmapcookie('yfxm') === '')
	{
		_$Cisdownloadflash = 1;
	}
	if(_$Cisdownloadflash === 1)
	{
		_$Cdownloadflash();
	}
	var _$Cclienturl = new Array();
	;
	var _$Cthehostname = _$Cdocument.location.hostname;
	var _$Cgetclienthost;
	for (_$Cgetclienthost in _$Cclienturl) {
		if (_$Cgetclienthost == _$Cthehostname) {
			_$Ccounturl_proxy = _$Cclienturl[_$Cgetclienthost];
			break
		}
	}
	function _$Cphpstat(cookietype,serverclientcookie) {
		var _$Cdoimgerr_1 = 1;
		var _$Creferrer = _$Cdocument.referrer;
		var _$Ctitle = _$Cdocument.title;
		var _$Chashcode = _$Cdocument.location.hash;
		var _$Clanguage = (navigator.systemLanguage ? navigator.systemLanguage : navigator.language);
		var _$Ccolor = screen.colorDepth;
		var _$Cclientwidth = _$Cdocument.documentElement.clientWidth;
		var _$Cclientheight = _$Cdocument.documentElement.clientHeight;
		var _$Cscrollheight = _$Cdocument.documentElement.scrollHeight;
		var _$Cscreensize = screen.width + '*' + screen.height;
		var _$Clastmodify = new Date(_$Cdocument.lastModified).getTime();
		var _$Ccookie = navigator.cookieEnabled ? 1 : 0;
		var _$Cutm_replace = ['utm_source','utm_medium','utm_campaign','utm_term','utm_content','utm_id','ca_kid','ca_source'];
		var _$Cutm_pmf_replace = ['pmf_group','pmf_medium','pmf_source','pmf_keyword','pmf_advname','pmf_id','pmf_id','pmf_group'];
		var _$Cbdu_replace = ['hmsr','hmmd','hmpl','hmci','hmkw','hmid'];
		var _$Cbdu_pmf_replace = ['pmf_group','pmf_medium','pmf_source','pmf_keyword','pmf_advname','pmf_id'];
		var _$Csearchkey = ['baidu','baidu','google','yahoo','sogou','bing','youdao','soso','haosou','sm','so'];
var _$Ckeyword = ['wd','word','q','p','query','q','q','w','q','q','q'];
var _$Csearchtype = ['default','default','default','default','default','default','default','default','default','default','default'];
var _$Ckeywordrelated = ['bs','bs','','','','','lq','bs','','',''];
;
		var _$Chostname = _$Cdocument.location.hostname + (_$Cdocument.location.port.length > 0 ? ':' + _$Cdocument.location.port : '');
		var _$Chostname_no_port = _$Cdocument.location.hostname;
		var _$Ccounturl_logcount = _$Ccounturl_proxy + '/noc.gif';
		var _$Cfirsttime;
		var _$Clasttime;
		var _$Cvisittime;
		var _$Cf_l_v_ck = 0;
		var _$Creturncount;
		var _$Cusercookie;
		var _$Csetusercookie;
		var _$Cserusercookie;
		var _$Cusername;
		var _$Cuserid;
		var _$Cuserregtime;
		var _$Cuserage;
		var _$Cusersex;
		var _$Cdomain = '';
		var _$Crefid = new Array();		
		var _$Cf_l_v_time = new Array();	
		var _$Cgtd = window._trackData;
		_$Crefid['phptag_recom_id'] = '';
		_$Cdomain	= _$Cgethost(_$Chostname_no_port);
		_Sauthor	= _$Ctypeof(_Sauthor);
		_Spage_type	= _$Ctypeof(_Spage_type);
		_Spage_pic	= _$Ctypeof(_Spage_pic);
		_Spage_id	= _$Ctypeof(_Spage_id);
		if (typeof(_Sload_time) == 'undefined') {
			_$Cdowntime = 0
		} else {
			_$Cstarttime = parseInt(_Sload_time);
			_$Cdowntime = _$Cdowntime - parseInt(_Sload_time)
		}
		_$Cfirsttime = _$Cgettimestr('f_t_');
		if (_$Cfirsttime === '') {
			_$Cfirsttime = _$Cgettime;
			_$Cf_l_v_ck = 1;
		}
			
		if( _$Cgtd && _$Cgtd.length )
		{
			for(var _$Ck in _$Cgtd)
			{
				if( !isNaN(_$Ck) )
				{
					for(var _$Ckk in _$Cgtd[_$Ck])
					{
						if( _$Cgtd[_$Ck]['0'] == 'userset' && _$Cgtd[_$Ck]['1'] == 'userid' && _$Cgtd[_$Ck]['2'].length )
						{		
							_$Cuserid = _$Cgtd[_$Ck]['2'];
							_$Csetflashcookie('yfx_s_u_id', _$Cgtd[_$Ck]['2'], 3650, _$Cdomain, '');
						}
						if( _$Cgtd[_$Ck]['0'] == 'userset' && _$Cgtd[_$Ck]['1'] == 'username' && _$Cgtd[_$Ck]['2'].length )
						{				
							_$Cusername = _$Cgtd[_$Ck]['2'];	
							_$Csetflashcookie('yfx_s_u_name', _$Cgtd[_$Ck]['2'], 3650, _$Cdomain, '');
						}
						if( _$Cgtd[_$Ck]['0'] == 'userset' && _$Cgtd[_$Ck]['1'] == 'age' && _$Cgtd[_$Ck]['2'].length )
						{					
							_$Cuserage = _$Cgtd[_$Ck]['2'];
							_$Csetflashcookie('yfx_s_u_age', _$Cgtd[_$Ck]['2'], 3650, _$Cdomain, '');
						}
						if( _$Cgtd[_$Ck]['0'] == 'userset' && _$Cgtd[_$Ck]['1'] == 'sex' && _$Cgtd[_$Ck]['2'].length )
						{				
							_$Cusersex = _$Cgtd[_$Ck]['2'];	
							_$Csetflashcookie('yfx_s_u_sex', _$Cgtd[_$Ck]['2'], 3650, _$Cdomain, '');
						}
						if( _$Cgtd[_$Ck]['0'] == 'userset' && _$Cgtd[_$Ck]['1'] == 'cookie' && _$Cgtd[_$Ck]['2'].length )
						{			
							_$Csetusercookie = _$Cgtd[_$Ck]['2'];		
							_$Csetflashcookie('yfx_s_c_g_u_id', _$Cgtd[_$Ck]['2'], 3650, _$Cdomain, '');
						}
						if( _$Cgtd[_$Ck]['0'] == 'userregtime' && _$Cgtd[_$Ck]['1'] == 'regtime' && _$Cgtd[_$Ck]['2'].length )
						{					
							_$Cuserregtime = _$Cgtd[_$Ck]['2'];	
							_$Csetflashcookie('yfx_s_u_reg', _$Cgtd[_$Ck]['2'], 3650, _$Cdomain, '');
						}
					}
				}
			}
		}
		_$Creturncount   = _$Cgettimestr('r_c_');
		_$Creturncount	= _$Creturncount === '' ? 0 : _$Creturncount; 
		_$Cusername		= _$Cusername || (_$Creadflashcookie('PHPSTATNULLCOOKIE') ? _$Creadflashcookie('PHPSTATNULLCOOKIE') : (_$Creadflashcookie('yfx_s_u_name')?_$Creadflashcookie('yfx_s_u_name'):_$Creadflashcookie('yfx_s_u_id')));	
		_$Cuserid		= _$Cuserid || (_$Creadflashcookie('PHPSTATNULLCOOKIE') ? _$Creadflashcookie('PHPSTATNULLCOOKIE') : (_$Creadflashcookie('yfx_s_u_id')?_$Creadflashcookie('yfx_s_u_id'):_$Creadflashcookie('yfx_s_u_name')));	
		_$Cuserage		= _$Cuserage || (_$Creadflashcookie('PHPSTATNULLCOOKIE') ? _$Creadflashcookie('PHPSTATNULLCOOKIE') : _$Creadflashcookie('yfx_s_u_age'));
		_$Cuserregtime	= _$Cuserregtime || (_$Creadflashcookie('PHPSTATNULLCOOKIE') ? _$Creadflashcookie('PHPSTATNULLCOOKIE') : _$Creadflashcookie('yfx_s_u_reg'));	
		_$Cusersex		= _$Cusersex || (_$Creadflashcookie('PHPSTATNULLCOOKIE') ? _$Creadflashcookie('PHPSTATNULLCOOKIE') : _$Creadflashcookie('yfx_s_u_sex'));
		_$Csetusercookie	= _$Csetusercookie || _$Creadflashcookie('yfx_s_c_g_u_id');
		_$Cusercookie	= _$Csetusercookie || _$Creadflashcookie('yfx_c_g_u_id');
		_$Cserusercookie	= serverclientcookie || _$Creadflashcookie('yfx_c_c_g_u_id');
		if( _$Csetusercookie === '' )
		{
			if (_$Cusercookie === '' && _$Cserusercookie === '' ) {
				_$Cusercookie = _$Cunique();
				_$Csetflashcookie('yfx_c_g_u_id', _$Cusercookie, 3650, _$Cdomain, '');
			}
			if (_$Cserusercookie && _$Cserusercookie !== _$Cusercookie) {
				_$Cusercookie = _$Cserusercookie;
				_$Csetflashcookie('yfx_c_g_u_id', _$Cserusercookie, 3650, _$Cdomain, '');
			}
		}
		else if( _$Csetusercookie )
		{
			_$Cusercookie = '_ck_'+_$Csetusercookie;
			_$Cserusercookie = '_ck_'+_$Csetusercookie;
		}
		_$Clasttime = _$Cgettimestr('r_t_');
		if (_$Clasttime === '') {
			_$Clasttime = _$Cgettime;
			_$Cf_l_v_ck = 1;
		}
		if (_$Cgettime - _$Clasttime >= 43200000) {
			_$Clasttime = _$Cgettime;
			_$Cf_l_v_ck = 1;
			_$Creturncount++;
		} else {
			_$Creturncount = _$Creturncount
		}
		_$Cvisittime = _$Cgettimestr('v_t_');
		if (_$Cvisittime === '' || (_$Cgettime - _$Cvisittime) >= 60000) {
			_$Cvisittime = _$Cgettime;
			_$Cf_l_v_ck = 1;
		}
		if( _$Cf_l_v_ck > 0 )
		{
			_$Cf_l_v_time['0'] = 'f_t_'+_$Cfirsttime;
			_$Cf_l_v_time['1'] = 'r_t_'+_$Clasttime;
			_$Cf_l_v_time['2'] = 'v_t_'+_$Cvisittime;
			_$Cf_l_v_time['3'] = 'r_c_'+_$Creturncount;
			_$Csetflashcookie('yfx_f_l_v_t', _$Cf_l_v_time.join('__'), 3650, _$Cdomain, '');
		}
		_$Cvisittime = '_vk' + _$Cvisittime;
		function _$Cgethost(gethost)
		{
			var _$Cpattern = new Array();
			var _$Cisdomain  = 0;
			var _$Cdomainlen = 0;
			_$Cpattern['.com.cn']	= 4;
			_$Cpattern['.net.cn']	= 4;
			_$Cpattern['.gov.cn']	= 4;
			_$Cpattern['.org.cn']	= 4;
			_$Cpattern['.com']	= 3;
			_$Cpattern['.net']	= 3;
			_$Cpattern['.org']	= 3;
			_$Cpattern['.gov']	= 3;
			_$Cpattern['.cc']	= 3;
			_$Cpattern['.biz']	= 3;
			_$Cpattern['.info']	= 3;
			_$Cpattern['.cn']	= 3;
			_$Cpattern['.hk']	= 3;			
			for( var $dk in _$Cpattern )
			{
				if( gethost.indexOf($dk) > -1 )
				{
					_$Cisdomain = 1;
					_$Cdomainlen = parseInt(_$Cpattern[$dk]);
					break;
				}
			}
			if( _$Cdomain.length <= 0 )
			{
				if( _$Cisdomain == 1 )
				{
					var s = gethost.split('.');
					if( s.length >= (_$Cdomainlen) )
					{
						s[0] = '';
						_$Cdomain = (s.join('.')).substr(1);
					}
					else
					{
						_$Cdomain = gethost;
					}
				}
				else
				{
					_$Cdomain = gethost;
				}
				return _$Cdomain;

			}
			else
			{
				return gethost;
			}
		}
		function _$Cgt() {
			return (new Date()).getTime();
		}
		function _$Cencode(s){
			return (typeof(encodeURIComponent)=="function")?encodeURIComponent(s):escape(s);
		}
		function _$Cdecode(s){
			return (typeof(decodeURIComponent)=="function")?decodeURIComponent(s):unescape(s);
		} 
		function _$Cid(id)
		{
			return _$Cdocument.getElementById(id);
		}
		function _$Cname(name)
		{
			return _$Cdocument.getElementsByName(name);
		}
		function _$Cunique() {
			var T = new Date();
			var Y = T.getYear();
			var M = T.getMonth()+1;
			var D = T.getDate();
			var H = T.getHours();
			var I = T.getMinutes();
			var S = T.getSeconds();
			var MS = T.getMilliseconds();
			Y = Y < 1900 ? Y + 1900 : Y;
			Y = (Y - 2000) <= 0 ? '10' : (Y - 2000);
			M = M < 10 ? '0'+''+M : M;
			D = D < 10 ? '0'+''+D : D;
			H = H < 10 ? '0'+''+H : H;
			I = I < 10 ? '0'+''+I : I;
			S = S < 10 ? '0'+''+S : S;
			MS = (MS + 999)+'';
			return '_ck'+Y+''+M+''+D+''+H+''+I+''+S+''+MS.substr(0,3)+''+Math.uuid(14,14);
		}
		function _$CgetYMD()
		{
			var T = new Date();
			var Y = T.getYear();
			var M = T.getMonth()+1;
			var D = T.getDate();
			Y = Y < 1900 ? Y + 1900 : Y;
			M = M < 10 ? '0'+''+M : M;
			D = D < 10 ? '0'+''+D : D;
			return Y+'-'+M+'-'+D;
		}
		function _$Cgettimestr(id)
		{
			id = id || 'f_t_';	
			var flvt_ret = '';
			var flvt_arr = _$Creadflashcookie('yfx_f_l_v_t').split('__');
			for(var vk in flvt_arr)
			{
				var vkv = _$Ctypeof(flvt_arr[vk]);
				if(vkv && vkv.indexOf(id) > -1)
				{
					flvt_ret = vkv.replace(id, '');
				}
			}
			return flvt_ret;
		}
		function _$Creadflashcookie(name) 
		{
			var cV = fcV = '';
			if ( !_$Cphpstat_flash_object && !_$Ccookie ) 
			{
				return 'not_support_cookie';
			}
			if (_$Cphpstat_flash_object) 
			{
				fcV = _$Ctypeof(_$Cphpstat_flash_object.get(name));
			}
			if (_$Ccookie) 
			{
				cV = _$Ctypeof(_$Creadcookie(name));
				if( cV !== fcV && fcV )
				{
					cV = fcV;
					_$Csetcookie(name, fcV, 3650, _$Cdomain, '');
				}
				if( fcV === '' && cV && _$Cphpstat_flash_object )
				{
					_$Csetflashcookie(name, cV, 3650, _$Cdomain, '');
				}
			}
			return cV;
		}
		function _$Creadcookie(name)
		{
			var cV = end = '';
			var v = 'yfx_cookie_group_'+_$Cwebsite+'=';
				v = name+'_'+_$Cwebsite+'=';
			if (_$Ccookie) 
			{
				var p = _$Cdocument.cookie.indexOf(v);
				if (p > -1) {
					p += v.length;
					end = _$Cdocument.cookie.indexOf(";", p);
					if (end == -1) {end = _$Cdocument.cookie.length;};
					cV = _$Cdecode(_$Cdocument.cookie.substring(p, end));
				}
				if( name != 'yfx_get_cookie_group' && 0 )
				cV = _$Cgetgroupcookie(cV,name);
				return _$Ctypeof(cV);
			}
			else
			{
				return 'not_support_cookie';
			}
		}
		function _$Csetflashcookie(name, gv, h, d, t) 
		{
			if ( !_$Cphpstat_flash_object && !_$Ccookie ) 
			{
				return 'not_support_cookie';
			}
			if (_$Cphpstat_flash_object) {
				_$Cphpstat_flash_object.set(name, gv);
			}
			if (_$Ccookie)
			{
				_$Csetcookie(name, gv, h, d, t);
			}
		}
		function _$Csetcookie(name, gv, h, d, t) 
		{
			var v = '';
			if (_$Ccookie) {
				v = new Date(_$Cgt() + parseInt(h)*24*60*60*1000);
				v = '; expires=' + v.toGMTString();
				if( t == '' && 0 )
				{
					gv = _$Csetgroupcookie(name, gv);
					name = 'yfx_cookie_group_'+_$Cwebsite;
				}
				name = name+'_'+_$Cwebsite;
				_$Cdocument.cookie = name + '=' + _$Cencode(gv) + v + ';domain='+d+';path=/;';
			}
			else
			{
				return 'not_support_cookie';
			}
		}
		function _$Cgetgroupcookie(jsonname,name)
		{
			var returnstr = '';
			var groupcookie = new Array();
			groupcookie = _$Cdecode(jsonname).split('|:|');
			for( var jk in groupcookie )
			{
				var gcs = _$Ctypeof(groupcookie[jk]);
				if( gcs.indexOf(name+'=') >= 0 )
				{
					returnstr = gcs.substring((name+'=').length);break;
				}
			}
			return _$Ctypeof(returnstr) || '';
		}

		function _$Csetgroupcookie(name,value)
		{
			var jsonname = _$Creadcookie('yfx_get_cookie_group') || '';
			if( jsonname.indexOf(name+'=') < 0 )
			{
				jsonname = jsonname + '|:|' + name + '=' + _$Ctypeof(value);
			}
			else
			{
				var groupcookie = new Array();
				groupcookie = _$Cdecode(jsonname).split('|:|');
				for( var jk in groupcookie )
				{
					groupcookie[jk] = _$Ctypeof(groupcookie[jk]);
					if( groupcookie[jk].indexOf(name+'=') >= 0 )
					{
						groupcookie[jk] = name + '=' + _$Ctypeof(value);
					}
				}
				jsonname = groupcookie.join('|:|');
			}
			return jsonname;
		}
		function _$Ctestnull(r)
		{
			if( typeof(r) === null || r === null )
			{
				return false;
			}
			else if( typeof(r) === 'undefined' || r === 'undefined' )
			{
				return false;
			}
			else
			{
				return true;
			}
		}
		function _$Cteststr(r)
		{
			if( typeof(r) === null || r === null )
			{
				return '';
			}
			else if( typeof(r) === 'undefined' || r === 'undefined' )
			{
				return '';
			}
			else if( r === '' )
			{
				return '';
			}
			else
			{
				return r;
			}
		}
		function _$Cgeturlparam(u) {
			var i = 0,j = 0;
			var h = '',p = '';
			if ((i = u.indexOf("://")) < 0 && u.length > 0) {return {h:u,p:''}};
			u = u.substring(i + 3);
			h = u.substring(0, u.indexOf('/'));
			if ((i = u.indexOf("/")) > -1) {			
				if ((j = u.indexOf('#clickmapcode=')) > -1) 
				{
					p = u.substring(i, j);
				}
				else
				{
					p = u.substring(i);
				}
			};
			return {h:h,p:p}
		}
		function _$Cgeturlkey(u,k)
		{
			var i,j,h='';
			if ((i = u.indexOf('?'+k+'=')) > -1 || (i = u.indexOf('&'+k+'=')) > -1)
			{
				h = u.substring(i+2+k.length);
				j = h.indexOf('&');
				j = j <= 0 ? h.length : j;
				{
					h = h.substring(0,j);
				}
			}
			return h;
		}
		function _$Cgetkeyword(u,b) {
			var v,dv,i, j, h, k, rk, e, ek, f, p = 10;
			u = u.toLowerCase();
			h = _$Cgeturlparam(u).h;
			if( b == '_' ){b = '';}
			for (var ii = 0; ii < _$Csearchkey.length; ii++) {
				if (h.toLowerCase().indexOf('.'+_$Csearchkey[ii].toLowerCase()+'.') > -1) {
					if ((i = u.indexOf('?' + _$Ckeyword[ii] + '=')) > -1 || (i = u.indexOf('&' + _$Ckeyword[ii] + '=')) > -1) {
						k = u.substring(i + _$Ckeyword[ii].length + 2);
						if(_$Csearchtype[ii]=='default')
						{_$Ckeywordsource = _$Csearchkey[ii]+b+'::'+k;}
						_$Ckeywordkey = k;
						v = '&KW=' + k + '&WC=' + _$Csearchtype[ii] + '&WP=' + _$Csearchkey[ii]+b;
						if ((i = k.indexOf('&')) > -1) {
							k = k.substring(0, i);
							if(_$Csearchtype[ii]=='default')
							{_$Ckeywordsource = _$Csearchkey[ii]+b+'::'+k;}
							_$Ckeywordkey = k;
							v = '&KW=' + k + '&WC=' + _$Csearchtype[ii] + '&WP=' + _$Csearchkey[ii]+b
						}
					}
					if ((i = u.indexOf('?' + _$Ckeywordrelated[ii] + '=')) > -1 || (i = u.indexOf('&' + _$Ckeywordrelated[ii] + '=')) > -1) {
						k = u.substring(i + _$Ckeywordrelated[ii].length + 2);
						rk = '&RW=' + k;
						if ((i = k.indexOf('&')) > -1) {
							k = k.substring(0, i);
							rk = '&RW=' + k
						}
					}
				}
			};
			v = v ? v : dv;
			if (_$Ctypeof(v) === '') {return '';}
			else if (rk) {return v + rk;}
			else {return v}
		}
		function _$Creplace_utm(s)
		{
			if( s.indexOf('pmf_source=') <= -1 )
			{
				if( s.indexOf('utm_source=') > -1 )
				{
					for (var ii = 0; ii < _$Cutm_replace.length; ii++) {
						s = s.replace(_$Cutm_replace[ii]+'=', _$Cutm_pmf_replace[ii]+'=');
					}
				}
				else if( s.indexOf('hmsr=') > -1 )
				{
					for (var ii = 0; ii < _$Cbdu_replace.length; ii++) {
						s = s.replace(_$Cbdu_replace[ii]+'=', _$Cbdu_pmf_replace[ii]+'=');
					}
				}
			}
			return s;
		}
		function _$Cgetmap(u) {
			var c = '';
			var s = new Array();
			if (u.indexOf('#clickmapcode=') > -1) {
				c = u.substring(14);
				s = c.split('|');
				s[2] = s[2] === '' ? _$Cwebsite : s[2];
				_$Csetcookie('yfxm', s[0], 1, _$Cdomain, '');
				_$Csetcookie('yfxm_t', s[1], 1, _$Cdomain, '');
				_$Csetcookie('yfxm_code', s[2], 1, _$Cdomain, '');
				_$Csetcookie('yfxm_site', s[3], 1, _$Cdomain, '');
				_$Csetcookie('yfxm_p', s[4], 1, _$Cdomain, '');
				_$Csetcookie('yfxm_s_d', s[5], 1, _$Cdomain, '');
				_$Csetcookie('yfxm_e_d', s[6], 1, _$Cdomain, '');
				_$Csetcookie('yfxm_sv', s[7], 1, _$Cdomain, '');
				_$Csetcookie('yfxm_p_g', s[8], 1, _$Cdomain, '');
				_$Csetcookie('yfxm_p_c', s[9], 1, _$Cdomain, '');
				_$Csetcookie('yfxm_c', s[10], 1, _$Cdomain, '');
				_$Csetcookie('yfxm_e', s[11], 1, _$Cdomain, '');
				_$Csetcookie('yfxm_o', s[12], 1, _$Cdomain, '');
				return {
					a: s[0],
					b: s[1],
					c: s[2],
					d: s[3],
					e: s[4],
					f: s[5],
					g: s[6],
					h: s[7],
					i: s[8],
					j: s[9],
					p: s[10],
					q: s[11],
					r: s[12],
					ht: s[13]||'',
					pu: s[14]||''
				}
			} else if (_$Creadcookie('yfxm') && _$Creadcookie('yfxm_code') && _$Creadcookie('yfxm_site')) {
				s[0] = _$Creadcookie('yfxm');
				s[1] = _$Creadcookie('yfxm_t');
				s[2] = _$Creadcookie('yfxm_code');
				s[3] = _$Creadcookie('yfxm_site');
				s[4] = _$Creadcookie('yfxm_p');
				s[5] = _$Creadcookie('yfxm_s_d');
				s[6] = _$Creadcookie('yfxm_e_d');
				s[7] = _$Creadcookie('yfxm_sv');
				s[8] = _$Creadcookie('yfxm_p_g');
				s[9] = _$Creadcookie('yfxm_p_c');
				s[10] = _$Creadcookie('yfxm_c');
				s[11] = _$Creadcookie('yfxm_e');
				s[12] = _$Creadcookie('yfxm_o');
				s[13] = _$Creadcookie('yfxm_h_h');
				s[14] = _$Creadcookie('yfxm_h_p');
				return {
					a: s[0],
					b: s[1],
					c: s[2],
					d: s[3],
					e: s[4],
					f: s[5],
					g: s[6],
					h: s[7],
					i: s[8],
					j: s[9],
					p: s[10],
					q: s[11],
					r: s[12],
					ht: s[13]||'',
					pu: s[14]||''
				}
			} else {return {
				a: '',
				b: '',
				c: '',
				d: '',
				e: '',
				f: '',
				g: '',
				h: '',
				i: '',
				j: '',
				p: '',
				q: '',
				r: '',
				ht: '',
				pu: ''
			}}
		}
		function _$Cgettag(u) {
			var c = '';
			var s = new Array();
			if (u.indexOf('#tagcontent=') > -1) {
				c = u.substring(12);
				s = c.split('|');
				return {
					a: s[0],
					b: s[1]
				}
			}
			else
			{
				return {
					a: '',
					b: ''
				}
			}
		}
		function _$Cgetpagetag(u) {
			var c = '';
			var s = new Array();
			if (u.indexOf('#pagecontent=') > -1) {
				c = u.substring(13);
				s = c.split('|');
				return {
					a: s[0],
					b: s[1],
					c: s[2]
				}
			}
			else
			{
				return {
					a: '',
					b: '',
					c: ''
				}
			}
		}
		function _$Cjsgif(gs) {
			if( _$Cis_can_record == 0 )
			{
				return;
			}
			var gif = new Image();
			gif.onload = function () {
				gif.onload = null;
				_$Cdoimgerr_1 = 1;
			};
			/*
			gif.onerror = function () {
				_$Cjsgif(gs);_$Cdoimgerr_1++;
			};
			*/
			if( _$Cdoimgerr_1 <= 2 )
			{
				gif.src = gs;
			};
		}
		function _$Cparseurl(u) {
			var p = new Array();
			u = u + '&phpstat';
			var c = u.replace(/^\?/,'').split('&');
			for (var b = 0; b < c.length; b++) {
				var e = c[b].split('=');
				p[e[0]] = e[1];
			}
			return p;
		}
		function _$Ctypeof(tp)
		{
			var rp=tp;
			if( tp === null ){rp = '';}
			else if( typeof(tp) === 'undefined' ){rp = '';}
			else if( typeof(tp) === 'object' ){rp = '';}
			else if( typeof(tp) === 'function' ){rp = '';}
			return rp;
		}
		function _$Csetfirst(fvar, nvalue)
		{
			if( _$Ctypeof(fvar) == '' )
			{			
				_$Csetcookie('yfx_mr_f', nvalue, 30, _$Cdomain, '');
			}
		}		
		var _$Cjava = 0;
		if (navigator.javaEnabled()) {_$Cjava = '1';}
		var _$Cbrowser = /(weibo|micromessenger)/.exec(_$Cuseragent);
		if (!_$Cbrowser) {_$Cbrowser = /(firefox|360se|sogou|lbbrowser|bidubrowser|tencenttraveler|theworld|maxthon|opera|ucweb|konqueror|lynx|greenbrowser|netcaptor|netscape|safari|chrome)/.exec(_$Cuseragent);}
		if (!_$Cbrowser) {_$Cbrowser = /(msie) ([0-9\.]*)[^;)]/.exec(_$Cuseragent);}
		_$Cbrowser = _$Cbrowser === null ? 'other' : _$Cbrowser[0];
		var _$Csystem = /(windows nt|windows|unix|linux|sunos|bsd|redhat|macintosh) ([0-9\.]*)[^;)]/.exec(_$Cuseragent);
		_$Csystem = _$Csystem === null ? 'other' : _$Csystem[0];
		var _$Calexa			= (_$Cuseragent.indexOf('alexa') !== -1) === false ? '0' : '1';
		var _$Cflash			= _$Cflashok.f;
		var _$Cpathname		= _$Cdocument.location.pathname;
		var _$Cfreferrer		= _$Cgeturlparam(_$Creferrer);
		var _$Cfreferrerhost = _$Cfreferrer.h;
		var _$Cref			= _$Cencode(_$Cfreferrer.p);
		var _$Cmapcode		= _$Cgetmap(_$Chashcode);
		var _$Ctagcode		= _$Cgettag(_$Chashcode);
		var _$Cpagecode		= _$Cgetpagetag(_$Chashcode);
		var _$Csearch		= _$Creplace_utm(_$Cdocument.location.search);
		if( _$Chashcode && 1 )
		{
			_$Csearch		= _$Csearch + _$Chashcode;
		}
		_$Cpathname			= _$Cencode(_$Cpathname + _$Csearch);
		_$Cpartner_website	= _$Creadflashcookie('yfx_p');
		_$Cmediumsource		= _$Creadflashcookie('yfx_mr');
		_$Cmediumsourcefirst	= _$Creadflashcookie('yfx_mr_f');
		_$Cedmemail			= _$Creadflashcookie('yfx_e');
		var _$Cis_can_record = 1;
		var _$Cparseurlarr	= _$Cparseurl(_$Csearch);
		var _$Cpmf_key		= _$Ctypeof(_$Cparseurlarr['k']);
		var _$Cpmf_from		= _$Ctypeof(_$Cparseurlarr['f']);
		var _$Cpmf_key_macth = _$Ctypeof(_$Cparseurlarr['m']);
		var _$Cpmf_key_word  = _$Ctypeof(_$Cparseurlarr['w']);
		var _$Cpmf_key_id	= _$Ctypeof(_$Cparseurlarr['kid']);
		var _$Cpmf_key_tid	= _$Ctypeof(_$Cparseurlarr['tid']);
		var _$Cpmf_gclid		= _$Ctypeof(_$Cparseurlarr['gclid']);
		var _$Cpmf_bdclkid	= _$Ctypeof(_$Cparseurlarr['bdclkid']);
		var _$Cpmf_group		= _$Ctypeof(_$Cparseurlarr['pmf_group']);
		var _$Cpmf_medium	= _$Ctypeof(_$Cparseurlarr['pmf_medium']);
		var _$Cpmf_source	= _$Ctypeof(_$Cparseurlarr['pmf_source']);
		var _$Cpmf_match		= _$Ctypeof(_$Cparseurlarr['pmf_match']);
		var _$Cpmf_keyword	= _$Ctypeof(_$Cparseurlarr['pmf_keyword']);
		var _$Cpmf_advname	= _$Ctypeof(_$Cparseurlarr['pmf_advname']);
		var _$Cpmf_partner	= _$Ctypeof(_$Cparseurlarr['pmf_partner']);
		var _$Cpmf_email		= _$Ctypeof(_$Cparseurlarr['pmf_email']);
		var _$Cpmf_area		= _$Ctypeof(_$Cparseurlarr['pmf_area']);
		var _$Cpmf_id		= _$Ctypeof(_$Cparseurlarr['pmf_id']);
		var _$Cpmf_tid		= _$Ctypeof(_$Cparseurlarr['pmf_tid']);
		var _$Cpmf_tui_id	= _$Cpmf_tid ? _$Cpmf_tid : _$Cpmf_key_tid;
		if (_$Cpmf_tui_id) {
			_$Csetflashcookie('yfx_f_id', _$Cpmf_tui_id, 3650, _$Cdomain, '');
		}
		else
		{
			_$Cpmf_tui_id = _$Creadflashcookie('yfx_f_id');
		}
		if(_$Cpagecode.a && _$Cpagecode.b && _$Cpagecode.c)
		{
			var ac = 'pageab_'+_$Cpagecode.a+'_'+_$Cpagecode.c;
			_$Csetflashcookie('yfx_p_ab_' + _$Cpagecode.a, _$Cpagecode.c, 30, _$Cdomain, 'new');
			_trackData.push(['addclick','HTML',ac,_$Cpagecode.c]);
		}
		if (_$Cmapcode.a && _$Cmapcode.b && _$Cmapcode.c) 
		{
			_$Cis_can_record = 0;
		}
		else if ( _$Chashcode.indexOf('#visitorplay') > -1 )
		{
			_$Cis_can_record = 0;
		}
		else if ( _$Chashcode.indexOf('#onlinevisitor') > -1 )
		{
			_$Cis_can_record = 0;
		}
		else if ( _$Cpathname.indexOf('fromclickhot') > -1 )
		{
			_$Cis_can_record = 0;
		}
		if( _$Cpmf_medium && _$Cpmf_medium.indexOf('market_type_') <= -1 )
		{
			_$Cpmf_medium = "market_type_"+_$Cpmf_medium;
		}
		var _$Cpstac			= _$Ctypeof(_$Cparseurlarr['pstac']);
		if( ( _$Cpmf_medium && _$Cpmf_source ) || ( ( _$Cpmf_gclid || _$Cpmf_bdclkid ) && _$Cpmf_key !== 'ppc' ) )
		{
			_$Cpmf_key = 'ppc';
		}
		var _$Cpmf_channel = _$Cpmf_medium;
		var _$Csearchkeyword  = _$Cgetkeyword(_$Creferrer,'_'+_$Cpmf_key);
		if (_$Cpmf_medium && _$Cpmf_source) {
			_$Cmediumsource = _$Cpmf_group+'::'+_$Cpmf_medium+'::'+_$Cpmf_source+'::'+_$Ckeywordsource+'::'+_$Cpmf_match+'::'+_$Cpmf_keyword+'::'+_$Cfreferrerhost+'::'+_$Cpmf_id+'::pmf_from_adv';
			_$Csetflashcookie('yfx_mr', _$Cmediumsource, 3650, _$Cdomain, '');
			_$Csetfirst(_$Cmediumsourcefirst, _$Cmediumsource);
			_$Csetflashcookie('yfx_key', _$Ckeywordkey, 3650, _$Cdomain, '');
		}
		else if (_$Cpmf_key && _$Cpmf_from && _$Cmediumsource.indexOf('pmf_from_adv') <= -1) {
			_$Cpmf_channel = 'market_type_paid_search';
			_$Cmediumsource = _$Cpmf_group+'::market_type_paid_search::::'+_$Ckeywordsource+'::'+_$Cpmf_key_macth+'::'+_$Cpmf_key_word+'::'+_$Cfreferrerhost+'::'+_$Cpmf_key_id+'_'+_$Cpmf_from+'_'+_$Cpmf_key+'::pmf_from_paid_search';
			_$Csetflashcookie('yfx_mr', _$Cmediumsource, 3650, _$Cdomain, '');
			_$Csetfirst(_$Cmediumsourcefirst, _$Cmediumsource);
			_$Csetflashcookie('yfx_key', _$Ckeywordkey, 3650, _$Cdomain, '');
		}
		else if (_$Ckeywordsource && _$Cmediumsource.indexOf('pmf_from_paid_search') <= -1 ) {
			_$Cpmf_channel = 'market_type_free_search';
			_$Cmediumsource = _$Cpmf_group+'::market_type_free_search::::'+_$Ckeywordsource+'::::::'+_$Cfreferrerhost+'::::pmf_from_free_search';
			_$Csetflashcookie('yfx_mr', _$Cmediumsource, 3650, _$Cdomain, '');
			_$Csetfirst(_$Cmediumsourcefirst, _$Cmediumsource);
			_$Csetflashcookie('yfx_key', _$Ckeywordkey, 3650, _$Cdomain, '');
		}
		_$Ckeywordkey = _$Creadcookie('yfx_key');
		if (_$Cpmf_partner) {
			_$Cpartner_website = _$Cpmf_partner;
			_$Csetflashcookie('yfx_p', _$Cpartner_website, 3650, _$Cdomain, '')
		}
		if (_$Cpmf_email) {
			_$Cedmemail = _$Cpmf_group+'::'+_$Cpmf_medium+'::'+_$Cpmf_source+'::'+_$Cpmf_email+'::'+_$Cpmf_area+'::pmf_from_edm';
			_$Csetflashcookie('yfx_e', _$Cedmemail, 3650, _$Cdomain, '')
		}
		_$Cmediumsourcefirst = _$Cmediumsourcefirst == _$Cmediumsource ? 'same' : _$Cmediumsource;
		var _$Ccourl = _$Ccounturl_logcount + '?WS=' + _$Cwebsite + '&RD=common&SWS='+_$Cteststr(_$Cpartner_website)+'&SWSID='+_$Cteststr(_Schannel_website_id)+'&SWSPID='+_$Cteststr(_Schannel_webshop_id)+'&JSVER=' + _$CVersion + '&TDT='+_$Cteststr(_trackDataType)+'&UC=' + _$Cusercookie + '&LUC=' + (_$Cserusercookie==_$Cusercookie?'same':_$Cserusercookie) + '&VUC=' + _$Cvisittime + '&FS=' + _$Cfreferrerhost + '&RF=' + _$Cencode(_$Cref) + '&PS=' + _$Chostname + '&PU=' + _$Cpathname + _$Csearchkeyword + '&PT=' + _Spage_type + '&PER=' + _$Ciserror + '&PC=' + _$Cencode(_Spage_pic) + '&PI=' + _Spage_id + '&LM=' + _$Clastmodify + '&LG=' + _$Clanguage + '&CL=' + _$Ccolor + '&CK=' + _$Ccookie + '&SS=' + _$Cscreensize + '&SCW=' + _$Cclientwidth + '&SCH=' + _$Cclientheight + '&SSH=' + _$Cscrollheight + '&FT=' + _$Cfirsttime + '&LT=' + _$Clasttime + '&DL=' + _$Cdowntime + '&FL='+_$Cflash+'&CKT='+cookietype+'&JV='+_$Cjava+'&AL=' + _$Calexa + '&SY=' + _$Cencode(_$Csystem) + '&BR=' + _$Cencode(_$Cbrowser) + '&TZ=' + (new Date()).getTimezoneOffset() / 60 + '&AU=' + _Sauthor + '&UN=' + _$Cencode(_$Cusername) + '&UID=' + _$Cencode(_$Cuserid) + '&URT=' + _$Cencode(_$Cuserregtime) + '&UA=' + _$Cencode(_$Cuserage) + '&US=' + _$Cencode(_$Cusersex) + '&TID=' + _$Cencode(_$Cpmf_tui_id) + '&MT=' + _$Ctelphone + '&FMSRC='+_$Cencode(_$Cmediumsourcefirst)+'&MSRC='+_$Cencode(_$Cmediumsource)+'&MSCH=&EDM='+_$Cencode(_$Cedmemail)+'&RC=' + _$Creturncount + '&SHPIC=&MID=' + _$Crandomid + '&TT=' + _$Cencode(_$Ctitle) + "&CHK=" + _$Cunicode(_$Cwebsite+_$Crandomid) + "&SHT=" + _$Cdomain + "&RDM=" + Math.random();
		var _$Cclickhotokstr = true;
		function _$Ccreatejs()
		{
			if (_$Cmapcode.a && _$Cmapcode.b && _$Cmapcode.c) 
			{
				_$Cclickhotokstr = false;
				var _$Curl = _$Ccounturl + '/clickareamap.js.php';
				var _$Cobj = _$Cdocument.createElement('script');
				_$Cobj.type = 'text/javascript';
				_$Cobj.async = true;
				_$Cobj.id = 'clickareamap_id';
				_$Cobj.charset = 'utf-8';
				
				var _$Cpage_site = _$Chostname;
				var _$Cpath_name = _$Cpathname;
				if(_$Cpathname.indexOf('clickhotcount')>-1 && _$Cmapcode.ht && _$Cmapcode.pu)
				{
					_$Cpage_site = _$Cmapcode.ht;
					_$Cpath_name = _$Cmapcode.pu;
				}	
				var _$Cdurl = _$Curl + '?jsprefix=yfx_&clicktype=' + _$Cmapcode.a + '&areatype=' + _$Cmapcode.b + '&website=' + _$Cmapcode.d + '&server=' + _$Cmapcode.h + '&starttime=' + _$Creadcookie('yfxm_s_d') + '&endtime=' + _$Creadcookie('yfxm_e_d') + '&fromtype=' + _$Creadcookie('yfxm_f') + '&pagesite=' + _$Cpage_site + '&pageurl=' + _$Cpath_name + '&pagegroup=' + _$Cmapcode.i + '&rand=' + Math.random() + '&clickmapcode=' + _$Cmapcode.c+'&clickmapposition=' + _$Cmapcode.e+'&counturl='+_$Cencode(_$Ccounturl)+'&type='+_$Cmapcode.j+'&chose='+_$Cmapcode.p+'&first='+_$Cmapcode.q+'&order='+_$Cmapcode.r + '&hashcode=' + _$Chashcode.substr(1);
				_$Cdocument.getElementsByTagName('head').item(0).appendChild(_$Cobj);
				setTimeout("_$Cdocument.getElementById('clickareamap_id').src='"+_$Cdurl+"'; ",1500);
			}
			if ( _$Chashcode.indexOf('#visitorplay') > -1 )
			{
				var _$Curl = _$Ccounturl + '/visitorplay.js.php';
				var _$Cobj = _$Cdocument.createElement('script');
				_$Cobj.type = 'text/javascript';
				_$Cobj.async = true;
				_$Cobj.id = 'visitorplay_id';
				_$Cobj.charset = 'utf-8';
				var _$Cdurl = _$Curl + '?counturl=' + _$Cencode(_$Ccounturl) + '&WS='+ _$Cwebsite + '&pagesite=' + _$Chostname + '&pageurl=' + _$Cpathname + '&hashcode=' + _$Chashcode.substr(1) + '&width=' + _$Cclientwidth + '&rand=' + Math.random();
				_$Cdocument.getElementsByTagName('head').item(0).appendChild(_$Cobj);
				setTimeout("_$Cdocument.getElementById('visitorplay_id').src='"+_$Cdurl+"'; ",1700);
			}
		}
			var _$Cformhiddenloop = 1;	
	var _$Cclickhot;
	var _$Cdoimgerr_2 = 1;
	var _$Cclickhotok = 0;
	var _$Cmessageid = '';
	var _$Cformhidden = 0||0;
	var _$Cclickarray = new Array();
	var _$Ccf_f = 1||0;
	var _$Ccfre_f = 0||0;
	_$Cclickarray[0]='(*)';;
	var _$Cclickreg = '';
	if (_$Cclickarray[0] == 'clickhotall') {
		_$Cclickhotok = 1
	}
	function _$Cdotest(r)
	{
		r = r+'';
		r = r.replace(/\\/g, '\\/');
		r = r.replace(/\//g, '\\/');
		r = r.replace(/\*/g, '(.*)');
		return r;
	}
	if (_$Cclickhot !== 'clickhot' && _$Cclickarray[0] !== 'clickhotall') {
		for (var ci = 0; ci < _$Cclickarray.length; ci++) {
			if (_$Cclickarray[ci].lastIndexOf('*') > - 1) {
				_$Cclickarray[ci] = _$Cdotest(_$Cclickarray[ci]);
				if (_$Cclickarray[ci].indexOf('/') === 0) {
					_$Cclickarray[ci] = _$Cclickarray[ci].substring(1)
				}
				_$Cclickreg = eval('/' + _$Cclickarray[ci] + '/ig');
				if (_$Cclickreg.test(_$Cpathname)) {
					_$Cclickhotok = 1;
					break
				}
			} else {
				if (_$Cclickarray[ci].indexOf('/') !== 0) {
					_$Cclickarray[ci] = '/' + _$Cclickarray[ci]
				}
				if (_$Cclickarray[ci] == _$Cpathname) {
					_$Cclickhotok = 1;
					break
				}
			}
		}
	}
	var _$Cclienturlstr = '';
	var _$Cposarr = new Array();

	function _$Ctimelong(ini) {
		var tl = _$Cgt() - _$Cstarttime;
		if (tl >= 1800000) {
			tl = 1000
		}
		if (ini) {
			tl = _$Cgt() - _$Ctimestart;
			_$Ctimestart = _$Cgt()
		}
		tl <= 0 ? 0 : tl;
		return tl
	}
	function _$Csetformfield(a,b)
	{
		if( typeof( _$Cformfielddetails[a][b] ) == null || typeof( _$Cformfielddetails[a][b] ) == 'undefined' )
		{
			_$Cformfielddetails[a][b] = {change:0,onkey:0,times:0,focus:0,errors:0,submits:0,inputinfo:0};
		}
	}
	function _$Cinitevent(init) {
		var _$Cfn;
		var _$Cfc;
		_$Caddlistener(window, 'unload', _$Cunload);
		_$Caddlistener(window, 'blur', _$Cunload);
		
		if( _$Ccf_f )
		{
			for (var a = 0; a < _$Cdocument.forms.length; a++) {
				_$Cfn = _$Cdocument.forms.item(a);
				_$Cfc = _$Cfn.name || _$Cfn.id;
				if( _$Cfc && _$Ccfre_f )
				{
					_$Cformlist = _$Cformlist + _$Cfc + "::" + _$Cfn.action + "||";
					_$Cformdetails[_$Cfc] = {change:0,onkey:0,times:0,focus:0,submits:0,errors:0,inputinfo:0};
					_$Cformfielddetails[_$Cfc] = {};
				}
				_$Cinitform(_$Cfn);
			}
			_$Cgetelementby(['form'], ['submit'], _$Csubmit);
			_$Cgetelementby(['select', 'input', 'textarea'], ['change'], _$Cchangeselect);
			_$Cgetelementby(['select', 'input', 'textarea','button'], ['blur'], _$Cfocus);
			_$Cgetelementby(['select', 'input', 'textarea','button'], ['click'], _$Cclick);
		}

		 if (init && 1) {
			_$Caddlistener(_$Cdocument, 'click', _$Cclick);
			_$Caddlistener(_$Cdocument, 'mousemove', _$Cmousemove)
		}
		if (init && _$Ccf_f && 0) {
			_$Caddlistener(_$Cdocument, 'keydown', _$Ckeydown);
			_$Caddlistener(_$Cdocument, 'keyup', _$Ckeyup);
		}
	}
	function _$Crecord(a) {
		var s = '';
		if (parseInt(Math.random() * 100) < 0*10 && a.a === 'msmv') return;
		switch (a.a) {
		case 'msmv':
			s = '||' + a.a + '::' + a.t + '::' + a.x + '::' + a.y + '::' + _$Cencode(a.i) + '::' + a.p;
			_$Ccountdourl(s);
			break;
		case 'clk':
		case 'fus':
		case 'link':
		case 'chn':
		case 'down':
		case 'onkey':
		case 'clkout':
		case 'submit':
			s = '||' + a.a + '::' + _$Cencode(a.tn) + '::' + _$Cencode(a.i) + '::' + _$Cencode(a.n) + '::' + a.tp + '::' + _$Cencode(a.v) + '::' + _$Cencode(a.h) + '::' + _$Cencode(a.u) + '::' + a.t + '::' + a.x + '::' + a.y + '::' + a.p + '::' + _$Cencode(a.fn) + '::' + _$Cencode(a.fa) + '::' + a.e + '::' + a.ef + '::' + _$Cencode(a.msg) + '::' + _$Cencode(a.ak) + '::' + _$Cencode(a.eor);
			_$Ccountdourl(s);
			break;
		default:
			_$Ccountdourl(a.a);
			break
		}
	}
	function _$Cunload() {
		_$Cloadgif(_$Cclienturlstr);
		_$Cclienturlstr = ''
	}
	function _$Ccountdourl(s) {
		_$Cclienturlstr += s;
		if (_$Cclienturlstr.length > 2048 && s) {
			_$Cloadgif(_$Cclienturlstr);
			_$Cclienturlstr = ''
		}
	}
	function _$Cdownload(p) {
		var ckda = new Array();
		ckda[0]='.doc';ckda[1]='.csv';ckda[2]='.xls';ckda[3]='.pdf';ckda[4]='.rar';ckda[5]='.zip';;
		var _pin = p.toLowerCase();
		for (var ckdi = 0; ckdi < ckda.length; ckdi++) {
			if (_pin.indexOf(ckda[ckdi]) > - 1) {
				return 1
			}
		}
		return 0
	}
	function _$Cclickout(h) {
		var ckoa = new Array();
		ckoa[0]='(*)';;
		var hi = h.toLowerCase();
		for (var ci = 0; ci < ckoa.length; ci++) {
				ckoa[ci] = _$Cdotest(ckoa[ci]);
		}
		var reg = eval('/'+ckoa.join('|')+'/ig');
		return (!reg.test(hi));
	}
	function _$Ctrackevent()
	{
		var s = '';
		var rs = '';
		var td = window._trackData;
		if( typeof(_trackEvent) !== 'undefined' && _trackEvent.trackActionUrl.length )
		{
			s = _trackEvent.trackActionUrl;
			_trackEvent.trackActionUrl = '';
		}
		else if( td && td.length )
		{
			for(var k in td)
			{
				if( !isNaN(k) )
				{
					for(var kk in td[k])
					{
						if( td[k]['0'] == 'viewgoods' )
						{
							for(var rd in _$Crefid)
							{
								rs = _$Ctypeof(_$Cparseurlarr[rd]);
								if( rs )
								{
									td[k]['9'] = rs;
								}
							}
						}
						if( _$Ctestnull(_Sorder_encode_url) === false )
						td[k][kk] = _$Cencode(td[k][kk]);
					}
					if( td[k].length == 1 )
					{
						s += '||'+td[k]['0'];
					}
					else
					{
						s += '||'+(td[k].join('::'));
					}
				}
			}
			window._trackData = [];
		}
		return s;
	}
	function _$Cdirecttrackevent()
	{
		if( typeof(_trackEvent) !== 'undefined' && _trackEvent.trackActionUrl.length )
		{
			_$Cloadgif('');
		}
		else if( window._trackData && window._trackData.length )
		{
			_$Cloadgif('');
		}
	}
	function _$Cloadgif(gs) {
		if( _$Cis_can_record == 0 )
		{
			return;
		}
		var gif = new Image();
		var clestr = gs + _$Ctrackevent();
		if( clestr.length <= 0 ) {return;}
		gif.onload = function () {
			gif.onload = null;
			_$Cdoimgerr_2 = 1;
		};
		/*
		gif.onerror = function () {
		   _$Cloadgif(gs);_$Cdoimgerr_2++;
		};*/
		if( _$Cdoimgerr_2 <= 2 )
		{
			gif.src = _$Ccounturl_logcount + '?WS=' + _$Cwebsite + '&RD=record&SWS='+_$Cteststr(_$Cpartner_website)+'&SWSID='+_$Cteststr(_Schannel_website_id)+'&SWSPID='+_$Cteststr(_Schannel_webshop_id)+'&JSVER=' + _$CVersion + '&TDT='+_$Cteststr(_trackDataType)+'&UC=' + _$Cusercookie + '&LUC=' + (_$Cserusercookie==_$Cusercookie?'same':_$Cserusercookie) + '&VUC=' + _$Cvisittime + '&UN=' + _$Cencode(_$Cusername) + '&UID=' + _$Cencode(_$Cuserid) + '&RC=' + _$Creturncount + '&PS=' + _$Chostname + '&PU=' + _$Cpathname + '&PT=' + _Spage_type + '&FS=' + _$Cfreferrerhost + '&RF=' + _$Cencode(_$Cref) + '&KW=' + _$Ckeywordkey + '&SS=' + _$Cscreensize + '&SW=' + _$Cscreen_width() + '&SCW=' + _$Cclient_width() + '&SCH=' + _$Cclientheight + '&SSH=' + _$Cscrollheight + '&BR=' + _$Cencode(_$Cbrowser) + '&LTL=' + Math.ceil(_$Ctimelong(1) / 1000) + '&MSRC='+_$Cencode(_$Cmediumsource)+'&EDM='+_$Cencode(_$Cedmemail)+'&CLE=' + clestr + '&MID=' + _$Crandomid+'&CHK=' + _$Cunicode(_$Cwebsite+_$Crandomid) + '&RDM='+Math.random();
		}
		if( _$Cpstac.toLowerCase() == 'debug' )
		_$Cmessage(gif.src);
	}
	function _$Caddlistener(a, b, c) {
		if (a.addEventListener) {
			a.addEventListener(b, c, false)
		} else {
			if (a.attachEvent) {
				a.attachEvent('on' + b, c)
			}
		}
	}
	function _$Cclick(ev) {
		_$Ccountimg(ev);
		var b = ev.srcElement || ev.target;
		if (b && /input/i.test(b.tagName) && /checkbox|radio/i.test(b.type)) {
			_$Cchange(b, b.checked)
		}
		if (b && /button|img|input/i.test(b.tagName) && /submit|button/i.test(b.type)) {
			_$Csubmit_button(b, ev)
		}
	}
	function _$Crecodeelement(ele,eleev,eleslt,type,host,url,eff,fname)
	{
		var $v = $e = $x = $y = $fn = $fa = $gfn = $typekey = $p = '';
		var $error = _$Cerrorcode || '';
		_$Cerrorcode = '';
		$x = _$Cposition(ele).x;
		$y = _$Cposition(ele).y;
		$p = ele.type;
		if(type == 'fus')
		{
			$v = _$Cgetvalue(ele);
		}
		if((type == 'clk' || type == 'down' || type == 'clkout')&&ele.tagName=='A')
		{
			$v = _$Cencode(ele.innerHTML.replace(/<[^>].*?>/g, '') || '');
			$x = _$Ccltxy(eleev).x;
			$y = _$Ccltxy(eleev).y;
			$e = _$Cencode(ele.getAttribute('phpstatevent') || '');
		}
		if(type == 'clk' && ele.tagName!=='A')
		{
			$v = _$Cgetvalue(ele);
			$x = _$Ccltxy(eleev).x;
			$y = _$Ccltxy(eleev).y;
		}
		if(type == 'chn')
		{
			$e = (eleslt === true ? 1 : (eleslt === false ? 0 : eleslt));
			$v = _$Cgetvalue(ele);
		}
		if(type == 'onkey')
		{
			$v = eff;
			$typekey = eleslt;
		}
		if(type == 'msmv')
		{
			$x = _$Ccltxy(eleev).x;
			$y = _$Ccltxy(eleev).y;
		}
		if((/input|textarea|select|button/i.test(ele.tagName)) || (/img/i.test(ele.tagName) && /submit|button/i.test(ele.type)))
		{		
			$gfn = _$Cgetformname(ele);
			$fn = $gfn.n;
			$fa = $gfn.a;
		}
		if(type == 'submit')
		{
			$gfn	= _$Cgetformname(ele);
			$fn		= $gfn.n;
			$fa		= $gfn.a;
		}	
		if( fname !== '' )
		{
			$fn = fname;
		}
		if( $p === 'password' && $v )
		{
			$v = '********';
		}
		$fa = '';
		var $ig={pose:'',tagid:''};
		$ig = _$Cinindeof(ele);
		var $fmsg = '';
		if( $fn && window._trackFormMsg && window._trackFormMsg.length > 0 )
		{
			$fmsg = window._trackFormMsg;
		}
		window._trackFormMsg = '';
		
		if( $fn && $fa && _$Ccfre_f )
		{
			var $eln_id = ele.name || ele.id;
			$eln_id = $eln_id || 'unname';
			_$Csetformfield($fn,$eln_id);
			if( $eln_id != 'unname' )
			{
				if(type == 'chn')
				{
					_$Cformdetails[$fn].change++;
					_$Cformfielddetails[$fn][$eln_id].change++;
					_$Cformdetails[$fn].inputinfo = $v;
					_$Cformfielddetails[$fn][$eln_id].inputinfo = $v;
				}
				if(type == 'onkey')
				{
					_$Cformdetails[$fn].onkey++;
					_$Cformfielddetails[$fn][$eln_id].onkey++;
				}
				if(type == 'fus')
				{
					_$Cformdetails[$fn].focus++;
					_$Cformfielddetails[$fn][$eln_id].focus++;
				}
				if(type == 'submit')
				{
					_$Cformdetails[$fn].submits++;
					_$Cformfielddetails[$fn][$eln_id].submits++;
				}
				if( $fmsg && $fmsg.indexOf('==failed') )
				{			
					_$Cformdetails[$fn].errors++;
					_$Cformfielddetails[$fn][$eln_id].errors++;
				}
				_$Cformdetails[$fn].times = _$Ctimelong(0);
				_$Cformfielddetails[$fn][$eln_id].times = _$Ctimelong(0);
			}
		}

		_$Crecord({
				a:  type,
				ak:  $typekey,
				p:  $ig.pose,
				h:  host,
				u:  url,
				t:  _$Ctimelong(0),
				n:  (_$Ctestobject(ele.name) || ''),
				i:  ($ig.tagid || _$Ctestobject(ele.id)),
				v:  $v,
				x:  $x,
				y:  $y,
				e:  $e,
				tp: (_$Ctestobject(ele.type) || ''),
				tn: (_$Ctestobject(ele.tagName) || ''),
				fn: $fn,
				fa: $fa,
				ef: eff,
				msg: $fmsg,
				eor: $error
			});
	}
	function _$Cfocus(ev) {
		if (!ev) {
			var ev = event
		}
		var b = ev.srcElement || ev.target;
		if (b && /input|textarea|select/i.test(b.tagName)) {
			_$Crecodeelement(b,ev,'','fus','','',0,'');
		}
	}
	function _$Conkey(ev,vc) {
		if (!ev) {
			var ev = event
		}
		var b = ev.srcElement || ev.target;
		var c = ev.keyCode || ev.charCode;
		if (/input|textarea|select/i.test(b.tagName)) {
			_$Crecodeelement(b,ev,vc,'onkey','','',c,'');
		}
	}
	function _$Ckeydown(ev)
	{
		_$Conkey(ev,'k_d');
	}
	function _$Ckeyup(ev)
	{
		_$Conkey(ev,'k_u');
	}
	function _$Ckeypress(ev)
	{
		_$Conkey(ev,'k_p');
	}
	function _$Ccountimg(ev) {
		if (!ev) {
			var ev = event
		}
		var b = ev.srcElement || ev.target;
		var c = b;
		while (b && (!b.href || /img/i.test(b.tagName))) {
			b = b.parentNode
		}
		var gettype = 'clk';
		var chu = clkhost = clkurl = '';
		if (b) {
			chu = _$Cgeturlparam(b.href);
			clkhost = chu.h;
			clkurl = chu.p;
			_$Crecodeelement(b,ev,'',gettype,clkhost,clkurl,0,'');
			if (_$Cdownload(b.href)) {
				gettype = 'down';
				_$Crecodeelement(b,ev,'',gettype,clkhost,clkurl,0,'');
			}
			if (_$Cclickout(clkhost)) {
				gettype = 'clkout';			
				_$Crecodeelement(b,ev,'',gettype,clkhost,clkurl,0,'');
			}
		}
		if (c&&b!=c) {
			var eff = 0;var effid = 'id';
			if ((/img|input|textarea|select|a/i.test(c.tagName))) {
				eff = 1
			}
			if ((/img/i.test(c.tagName)) && chu) {
				effid = c.id || '';
			}
			if( effid == 'id' || effid )
			{
				_$Crecodeelement(c,ev,'','clk','','',eff,'');
			}
		}
	}
	function _$Cscreen_width() {
		return _$Cdocument.documentElement.scrollWidth;
	}
	function _$Cclient_width() {
		return _$Cdocument.documentElement.clientWidth;
	}
	function _$Ctestnull(r)
	{
		if( typeof(r) === null )
		{
			return false;
		}
		else if( typeof(r) === 'undefined' )
		{
			return false;
		}
		else
		{
			return true;
		}
	}
	function _$Ctestobject(r)
	{
		if( typeof(r) === 'object' )
		{
			return '';
		}
		else
		{
			return r;
		}
	}
	function _$Cinindeof(c) {
		while (c && !c.tagName) {
			c = c.parentNode
		}
		var i = 0;
		var b = c;
		var phptag = '';
		var fetchtag = 'phptag';
		var parentnodes = new Array();
		var resultarray = new Array();
		var resultarraystr = new Array();
		while (b && b !== _$Cdocument.body && b !== _$Cdocument.documentElement) {
			var ch = 1;
			var g = new Array();
			if(!_$Ctestnull(b.parentNode)||!b.parentNode) break;
			g = b.parentNode.childNodes;
			for (var e = 0; e < g.length; e++) {
				if (g[e].tagName && g[e].tagName !== '!' && g[e].tagName !== 'SCRIPT') {
					if (g[e] == b) {
						break
					}
					ch++
				}
			}
			if( ch < 10 )
			{
				parentnodes[i] = '0'+ch;
			}
			else
			{
				parentnodes[i] = ch;
			}
			phptag = phptag == '' ? (b.getAttribute(fetchtag)||'') : phptag;
			b = b.parentNode;
			i++
		}
		resultarray = parentnodes.reverse();
		resultarraystr = resultarray.join('-');
		return {pose:resultarraystr,tagid:phptag}
	}
	function _$Cgetformname(c)
	{
		while (c && !c.tagName) {
			c = c.parentNode
		}
		var b = c;
		if(/input|textarea|select|img|button/i.test(c.tagName))
		{
			var i = 0;
			while ( b && b.tagName !== 'FORM' ) 
			{
				if( b.tagName == 'BODY' )break;
				b = b.parentNode;
				i++;
			}
		}
		if( b && b.tagName == 'FORM' )
		{
			return {
				n: ((b.getAttribute('name') || b.getAttribute('id')) || ''),
				a: (b.getAttribute('action') || _$Cpathname)
			}
		}
		else
		{
			return {
				n: '',
				a: ''
			}
		}
	}
	function _$Cposition(b) {
		var a = {
			x: 0,
			y: 0
		};
		while (b.offsetParent) {
			a.x += parseInt(b.offsetLeft);
			a.y += parseInt(b.offsetTop);
			b = b.offsetParent
		}
		a.x += parseInt(b.offsetLeft);
		a.y += parseInt(b.offsetTop);
		return a
	}
	function _$Cgetxy() {
		var x = 0;
		var y = 0;
		if (_$Cdocument.body.scrollTop) {
			x = parseInt(_$Cdocument.body.scrollLeft);
			y = parseInt(_$Cdocument.body.scrollTop);
		} else {
			x = parseInt(_$Cdocument.documentElement.scrollLeft);
			y = parseInt(_$Cdocument.documentElement.scrollTop);
		};
		return {
			x: x,
			y: y
		}
	}

	function _$Cistable(a) {
		return (a.tagName == 'TBODY' || a.tagName == 'TR')
	}
	function _$Cchangeselect(c) {
		var b = c.srcElement || c.target;
		if (/input/i.test(b.tagName) && /checkbox|radio/i.test(b.type)) {
			_$Cchange(b, b.checked)
		} else if (/input/i.test(b.tagName) && /text/i.test(b.type)) {
			_$Cchange(b, b.value.length)
		} else if (/textarea/i.test(b.tagName)) {
			_$Cchange(b, _$Ctxt_len(b.value))
		} else if (/select/i.test(b.tagName)) {
			_$Cchange(b, b.selectedIndex)
		}
	}
	function _$Cchange(b, a) {
		if (b.lastvalue && b.lastvalue == a) {
			return;
		};
		_$Crecodeelement(b,'',a,'chn','','',0,'');
		_$Cgetby_idname(b);
		_$Chiddenele(b,b);
		b.lastvalue = a;
	}
	function _$Cchange_com(b, a) {
		if (b.lastvalue && b.lastvalue == a) {
			return
		};
		b.lastvalue = a;
	}
	function _$Cinitform(b) 
	{
		for (var a = 0; a < b.elements.length; a++) {
			var c = b.elements[a];
			if (/input/i.test(c.tagName) && /checkbox|radio/i.test(c.type)) 
			{
				_$Cchange_com(c, c.checked);
			} 
			else
			{
				if (/input/i.test(c.tagName) && /text/i.test(c.type)) 
				{
					_$Cchange_com(c, c.value.length);
				} 
				else 
				{
					if (/textarea/i.test(c.tagName)) 
					{
						_$Cchange_com(c, _$Ctxt_len(c.value));
					} 
					else 
					{
						if (/select/i.test(c.tagName)) 
						{
							_$Cchange_com(c, c.selectedIndex);
						}
					}
				}
			}
		}
	}
	function _$Ctxt_len(a) {
		return a.length - (a.split("\r").length - 1)
	}
	function _$Ccltxy(ev) {
		if (!ev) {
			var ev = event
		}
		var y = parseInt(ev.clientY) + parseInt(_$Cgetxy().y) - parseInt(_$Cdocument.getElementsByTagName('body')[0].offsetTop);
		var x = parseInt(ev.clientX) + parseInt(_$Cgetxy().x) - parseInt(_$Cdocument.getElementsByTagName('body')[0].offsetLeft);
		if (x > 5000 || x < 0) {
			x = 0
		}
		if (y > 50000 || y < 0) {
			y = 0
		}
		return {
			x: x,
			y: y
		}
	}
	function _$Cmousemove(ev) {
		var t = _$Cgt();
		var e = ev.srcElement || ev.target;
		if ((t - _$Cloadtime) > (parseInt(0) + 1) * 100) {_$Crecodeelement(e,ev,0,'msmv','','','','');}
		_$Cloadtime = t
	}

	function _$Cgetvalue(a) {
		var rv = '';
		if (a.tagName == 'SELECT') {
			rv = a.options[a.selectedIndex].text || ''
		}
		else {
			rv = a.value || '';
			if(rv==''&&_$Ctestchildren(a)==1)
			{
				rv = a.innerHTML.replace(/<[^>].*?>/g, '') || '';
			}
		}
		rv = _$Cteststr(_$Cencode(rv.replace(/\s/g, '')));
		return rv.substring(0, 512)
	}
	function _$Csubmit(ev) {
		if (!ev) {
			var ev = event
		}
		var b = ev.srcElement || ev.currentTarget;
		if( b )
		{
			_$Crecodeelement(b,ev,'','submit','','',0,'');
		}
	}
	function _$Chiddenele(f,t)
	{
		var loop = 1;
		while ( f && f.tagName !== 'FORM' && loop <= 10 ) 
		{
			if( f && f.tagName === 'BODY' )break;
			f = f.parentNode;
			t = f;
			loop++;
		}
		if( f && f.tagName === 'FORM' && _$Cformhiddenloop <= 10 ) 
		{
			var b = t.childNodes;
			for (var i = 0; i < b.length; i++) 
			{
				if(b[i] && b[i].tagName === 'INPUT' && (b[i].type === 'hidden'||b[i].style.display === 'none')) 
				{
					var b_lastvalue = _$Cteststr(_$Cgetvalue(b[i]));
					b[i].lastvalue = _$Cteststr(b[i].lastvalue);
					if( b_lastvalue && b[i].lastvalue !== b_lastvalue )
					{
						_$Crecodeelement(b[i],'','','chn','','',0,'');
						b[i].lastvalue = b_lastvalue;
					}
				}
				else
				{
					_$Chiddenele(f,b[i]);
					_$Cformhiddenloop++;
				}
			}
		}
	}
	function _$Ctestchildren(f)
	{
		if( f ) 
		{
			return f.childNodes.length;
		}
		else
		{
			return 0;
		}
	}
	function _$Csubmit_button(b,ev) {
		var i = 0;
		while ( b && b.tagName !== 'FORM' && i <= 10 ) 
		{
			if( b && b.tagName == 'BODY' )break;
			b = b.parentNode;
			i++;
		}
		if( b && b.tagName == 'FORM' )
		{
			_$Crecodeelement(b,ev,'','submit','','',0,'');
			_$Cgetby_idname(b);
			_$Chiddenele(b,b);
		}
	}
	function _$Cgetby_idname(b)
	{
		var i = 0;
		while ( b && b.tagName !== 'FORM' && i <= 10 ) 
		{
			if( b && b.tagName == 'BODY' )break;
			b = b.parentNode;
			i++;
		}

		if( b && b.tagName === 'FORM' && b.name && _$Cformlist && _$Cformhidden )
		{
			var gh = phpstat_do_hidden_form(b.name);
			for(var ghk in gh)
			{
				var _fidv = _$Cteststr(_$Cid(gh[ghk]['ffield']));
				if( _fidv === '' )
				{
					var _fidva = _$Cname(gh[ghk]['ffield']);	
					if( _fidva.length > 0 )
					{
						_fidv = _fidva['0'];
					}
				}
				if( _fidv )
				{
					var b_lastvalue = _$Cteststr(_$Cgetvalue(_fidv));
					_fidv.lastvalue = _$Cteststr(_fidv.lastvalue);
					if( b_lastvalue && _fidv.lastvalue !== b_lastvalue )
					{
						_$Crecodeelement(_fidv,'','','chn','','',0,b.name);
						_fidv.lastvalue = b_lastvalue;
					}
				}
			}
		}
	}
	function _$Cgetelementby(b, f, a) {
		for (var d = 0; d < b.length; d++) {
			var j = _$Cdocument.getElementsByTagName(b[d]);
			for (var c = 0; c < j.length; c++) {
				for (var g = 0; g < f.length; g++) {
					_$Caddlistener(j[c], f[g], a)
				}
			}
		}
	}
	function _$Cgetmessageid(a) {
		if (a.toLowerCase() == 'debug') {
			setTimeout(function(){var _$Cobj = _$Cdocument.createElement("div");
			_$Cobj.innerHTML = '<textarea id="pst_messageid" name="message" rows="12" cols="100" style="position: absolute; left:10px; bottom:20px; border: solid #6C358D;">'+_$Ccourl+'</textarea>';
			_$Cdocument.getElementsByTagName('body').item(0).appendChild(_$Cobj);_$Cmessageid = _$Cdocument.getElementById('pst_messageid');},3000);     
		}
	}
	function _$Cmessage(a) {
		if (_$Cmessageid) {
			_$Cmessageid.value = a;
		}
	}
	_$Cgetmessageid(_$Cpstac);
	_$Cclickhotokstr ? setTimeout(function(){_$Cinitevent(_$Cclickhotok);},3000) : '';
	window.setInterval(function(){_$Cunload();}, 5000);
	_$Cdirecttrackevent();
		_$Cjsgif(_$Ccourl);
		_$Ccreatejs();
		_$Cshare(_$Cusercookie);
	}
	function _$Cshare(userunique){};;
	if( _$Cprotocol.toString().toLowerCase().indexOf('http') > -1 )
	{
		if(_$Cisdownloadflash === 0)
		{			
			var ghostvar = _$Csplitdomain(_$Cthehostname);
			var _$Cclientcookie = _$Creadmapcookie("yfx_c_c_g_u_id");
			if( _$Cchkdomain && _$Ccounturl.indexOf(_$Cchkdomain) > -1 && _$Cclientcookie === '' && false)
			{
				_$Cgetservercookie(ghostvar,'outfunc');
			}
			else
			{
				_$Cphpstat('HttpCookie','');
			}
		}
		else
		{
			_$Cphpstat_flash_object = new phpstatCookie({

					namespace: 'namespace_phpstat',
					swf_url: _$Ccounturl_proxy+'/cookie/storage.swf?'+Math.random(), 
					debug: false,
					onready: function() {
					_$Cphpstat('FlashCookie','');
					},
					onerror: function() {
					_$Cphpstat('FlashCookie-err','');
					}
				});
		}
	}
}
catch(e)
{
};/*aa510230a6c2cd1ac50752935fa3e0cb*/
