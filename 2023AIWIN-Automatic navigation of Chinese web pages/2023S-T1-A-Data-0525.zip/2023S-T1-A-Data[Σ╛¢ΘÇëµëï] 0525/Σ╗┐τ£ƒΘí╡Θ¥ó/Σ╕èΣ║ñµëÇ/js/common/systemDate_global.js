function get_systemDate_global(){
var systemDate_global  = "2023-02-22";
return systemDate_global;}function get_whetherTradeDate_global(){
var whetherTradeDate_global  = true;
return whetherTradeDate_global;}function get_lastTradeDate_global(){
var lastTradeDate_global  = "2023-02-21";
return lastTradeDate_global;}