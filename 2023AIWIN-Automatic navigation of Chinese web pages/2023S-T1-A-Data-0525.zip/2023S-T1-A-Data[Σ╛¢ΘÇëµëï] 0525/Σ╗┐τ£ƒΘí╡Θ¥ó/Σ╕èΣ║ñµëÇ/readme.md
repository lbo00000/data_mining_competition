### 打开方式：
  使用serve运行
### 步骤：
  1.打开终端，进入文件夹所在目录；
  2.输入命令：serve
  3.本地服务开启后，终端会显示当前服务的路径（例如：http://localhost:3000，端口被占用时，会使用其他端口）
  
### 查询页
http://localhost:3000/assortment/stock/list/share/nosearch