/**
 * 官网首页方法
 */
var homePage = {
  announceFileUrl: "/disclosure/listedinfo/announcement/json/", //上市公司公告静态文件存放路径
  recentTypeUrl: "stock_bulletin_publish_order.json", //上市公告json
  today_date: get_systemDate_global(), //当前系统时间
  recentAnnounceUrl: sseQueryURL + "security/stock/queryCompanyBulletinNew.do", //上市公告接口
  recentAnnounceParam: {
    //上市公告参数
    isPagination: true,
    "pageHelp.pageSize": 8,
    "pageHelp.cacheSize": 1,
    START_DATE: "", //开始日期
    END_DATE: "", //结束日期
    SECURITY_CODE: "", //证券代码
    TITLE: "", //关键字
    BULLETIN_TYPE: "", //公告类型
  },
  bondAnnounceUrl: sseQueryURL + "commonSoaQuery.do?", //债券公告接口
  bondAnnounceFileUrl:
    "/disclosure/bond/bookentry/announcement/json/bond_bulletin_publish_order.json",
  bondAnnounceParam: {
    isPagination: true,
    "pageHelp.pageSize": 8,
    sqlId: "BS_ZQ_GGLL",
    orgBulletinType: "",
    title: "",
    securityCode: "",
    order: "sseDate|desc,securityCode|asc,bulletinId|asc",
    // siteId: 28,
    // sqlId: 'BS_GGLL',
    // extGGLX: '0',
    // isPagination: true,
    // stockcode: '',
    // channelId: 9857,
    // createTime: '',
    // createTimeEnd: '',
    // extGGDL: '',
    // order: 'createTime|desc,stockcode|asc',
    // 'pageHelp.pageSize': 8,
    // 'pageHelp.pageCount': 8,
    // 'pageHelp.pageNo': 1,
    // 'pageHelp.beginPage': 1,
    // 'pageHelp.cacheSize': 1,
    // 'pageHelp.endPage': 8,
  },
  fundFileUrl: "/disclosure/fund/announcement/json/", //基金公告静态文件存放路径
  fundTypeUrl: "fund_bulletin_publish_order.json", //基金公告json
  fundAnnounceUrl: sseQueryURL + "commonQuery.do?", //基金公告接口
  fundAnnounceParam: {
    sqlId: "COMMON_PL_JJXX_JJGG_L",
    isPagination: true,
    SECURITY_CODE: "",
    ORG_BULLETIN_TYPE: "",
    OTHER_TYPE: "",
    START_DATE: "",
    END_DATE: "",
    "pageHelp.pageSize": 8,
    "pageHelp.pageCount": 8,
    "pageHelp.pageNo": 1,
    "pageHelp.beginPage": 1,
    "pageHelp.cacheSize": 1,
    "pageHelp.endPage": 8,
  },
  //默认方法及点击事件
  init: function () {
    homePage.loadEvents();
    homePage.getHightChart(); //主要指数
    homePage.getStaticRecent(); //静态上市公告
    homePage.getStaticBond(); //静态债券公告
    homePage.getStaticFund(); //静态基金公告
  },
  loadEvents: function () {
    /* 热点动态默认“本所动态”tab展示 */
    $(".js_news_more h1 a").attr("href", "/aboutus/mediacenter/hotandd/");
    //热点动态判断图片显示或隐藏
    $(".hot_dyn li").each(function () {
      var hotImg = $(this).children("img");
      if (hotImg.attr("src")) {
        hotImg.css("display", "block");
      }
    });
    //公告添加more按钮
    $(".js_announceTab").append(
      '<a  target="_blank" class="bi-arrow-right-circle"></a>'
    );
    // $(".js_announceTab").on("click", "span", function () {
    //   var announcementLink = $(this).attr("data-value");
    //   $(".js_announceTab a").attr("href", announcementLink);
    // });
    //判断首页banner是否自动轮播
    var homeBannerLoop = false;
    homeBannerLoop =
      $(".js_swiper-container-carousel .swiper-slide").length > 1
        ? true
        : false; //slide个数大于1:loop=true
    setSwiper({
      el: ".js_swiper-container-carousel",
      param: {
        autoplay: {
          delay: 8000,
          disableOnInteraction: false,
        },
        speed: 900,
        loop: homeBannerLoop,
        navigation: {
          nextEl: ".js_swiper-container-carousel .swiper-button-next-car",
          prevEl: ".js_swiper-container-carousel .swiper-button-prev-car",
        },
        pagination: {
          el: ".swiper-pagination",
          clickable: true,
        },
      },
    });
    //移动端
    var mobileBannerLoop = false;
    mobileBannerLoop =
      $(".js_swiper-container-carousel-mobile .swiper-slide").length > 1
        ? true
        : false; //slide个数大于1:loop=true
    setSwiper({
      el: ".js_swiper-container-carousel-mobile",
      param: {
        autoplay: {
          delay: 8000,
          disableOnInteraction: false,
        },
        speed: 900,
        loop: mobileBannerLoop,
        navigation: {
          nextEl:
            ".js_swiper-container-carousel-mobile .swiper-button-next-car",
          prevEl:
            ".js_swiper-container-carousel-mobile .swiper-button-prev-car",
        },
      },
    });
    //近期上市轮播图
    var recentListingLoop = false;
    recentListingLoop =
      $(".js_swiper-container-dyna-new .swiper-slide").length > 1
        ? true
        : false; //slide个数大于1:loop=true
    setSwiper({
      el: ".js_swiper-container-dyna-new",
      param: {
        autoplay: {
          delay: 6000,
          disableOnInteraction: false,
        },
        speed: 800,
        loop: recentListingLoop,
        navigation: {
          nextEl: ".swiper-button-next-dyna",
          prevEl: ".swiper-button-prev-dyna",
        },
        pagination: {
          el: ".swiper-pagination-com",
          clickable: true,
          renderBullet: function (index, className) {
            return '<div class="' + className + '"><span></span><i></i></div>';
          },
        },
      },
    });
    //服务窗口轮播图
    setSwiper({
      el: "#js_owl-service",
      param: {
        autoplay: {
          delay: 7000,
          disableOnInteraction: false,
        },
        speed: 900,
        loop: true,
        loopFillGroupWithBlank: true,
        slidesPerView: 6,
        slidesPerGroup: 6,
        breakpoints: {
          320: {
            slidesPerView: 2,
            slidesPerGroup: 2,
          },
          //当宽度大于等于768
          768: {
            slidesPerView: 4,
            slidesPerGroup: 4,
          },
          //当宽度大于等于1280
          1280: {
            slidesPerView: 6,
            slidesPerGroup: 6,
          },
        },
        pagination: {
          el: ".swiper-pagination-win",
          clickable: true,
        },
      },
    });
    //本所网站轮播图
    setSwiper({
      el: ".js_ourSite .swiper-container",
      param: {
        autoplay: {
          delay: 5000,
          disableOnInteraction: false,
        },
        speed: 900,
        loop: true,
        loopFillGroupWithBlank: true,
        slidesPerView: 3,
        slidesPerGroup: 3,
        spaceBetween: 20,
        breakpoints: {
          320: {
            slidesPerView: 1,
            slidesPerGroup: 1,
            spaceBetween: 10,
          },
          768: {
            slidesPerView: 2,
            slidesPerGroup: 2,
            spaceBetween: 20,
          },
          992: {
            slidesPerView: 3,
            slidesPerGroup: 3,
            spaceBetween: 20,
          },
        },
        pagination: {
          el: ".swiper-pagination-site",
          clickable: true,
          renderBullet: function (index, className) {
            return '<div class="' + className + '"><span></span><i></i></div>';
          },
        },
      },
    });
    //市场数据初始化
    homePage.getMarketData();
    //给公告搜索框placeholder赋值
    $(".js_bondAnnounce input").attr("placeholder", "请输入代码");
    $(".js_fundAnnounce input").attr("placeholder", "请输入代码");
    //上市公告点击搜索
    $(".js_recentAnnounce").on("click", ".bi-search", function () {
      return
      homePage.toSearchRecent();
    });
    //enter搜索上市公告
    $(".js_recentAnnounce").on(bind_name, function (e) {
      var keyCode = e.keyCode || e.which || e.charCode;
      if (keyCode == 13) {
        homePage.toSearchRecent();
      } else {
        $(".js_recentAnnounce .search_error").html("");
        $(".js_recentAnnounce .sse_searchAnnounceInput").removeClass(
          "sse_searchError"
        );
      }
    });
    //上市公告清除
    $(".js_recentAnnounce").on("click", ".clear_reset", function () {
      homePage.getStaticRecent();
      $(".js_recentAnnounce input").val("");
      $(".js_recentAnnounce .search_error").html("");
      $(".js_recentAnnounce .sse_searchAnnounceInput").removeClass(
        "sse_searchError"
      );
    });
    //债券公告点击搜索
    $(".js_bondAnnounce").on("click", ".bi-search", function () {
      return
      homePage.toSearchBond();
    });
    //enter搜索债券公告
    $(".js_bondAnnounce").on(bind_name, function (e) {
      var keyCode = e.keyCode || e.which || e.charCode;
      if (keyCode == 13) {
        homePage.toSearchBond();
      } else {
        $(".js_bondAnnounce .search_error").html("");
        $(".js_bondAnnounce .sse_searchAnnounceInput").removeClass(
          "sse_searchError"
        );
      }
    });
    //债券公告清除
    $(".js_bondAnnounce").on("click", ".clear_reset", function () {
      homePage.getStaticBond();
      $(".js_bondAnnounce input").val("");
      $(".js_bondAnnounce .search_error").html("");
      $(".js_bondAnnounce .sse_searchAnnounceInput").removeClass(
        "sse_searchError"
      );
    });
    //基金公告点击搜索
    $(".js_fundAnnounce").on("click", ".bi-search", function () {
      return
      homePage.toSearchFund();
    });
    //enter搜索基金公告
    $(".js_fundAnnounce").on(bind_name, function (e) {
      var keyCode = e.keyCode || e.which || e.charCode;
      if (keyCode == 13) {
        homePage.toSearchFund();
      } else {
        $(".js_fundAnnounce .search_error").html("");
        $(".js_fundAnnounce .sse_searchAnnounceInput").removeClass(
          "sse_searchError"
        );
      }
    });
    //基金公告清除
    $(".js_fundAnnounce").on("click", ".clear_reset", function () {
      homePage.getStaticFund();
      $(".js_fundAnnounce input").val("");
      $(".js_fundAnnounce .search_error").html("");
      $(".js_fundAnnounce .sse_searchAnnounceInput").removeClass(
        "sse_searchError"
      );
    });

    //右侧锚点
    if ($(document).scrollTop() < 450) {
      $(".home_anchor").hide();
    } else {
      $(".home_anchor").show();
    }
    //搜索框吸顶之后显示goTop
    window.onscroll = function () {
      setTimeout(function () {
        if ($(".sse_searchContainer").hasClass("search_fixed")) {
          $(".js_goTop").css("opacity", "1");
        } else {
          $(".js_goTop").css("opacity", "0");
        }
      }, 1000);
      if ($(document).scrollTop() < 450) {
        $(".home_anchor").fadeOut();
      } else {
        $(".home_anchor").fadeIn();
      }
    };
    //回到顶部
    $(".js_goTop").on("click", function (e) {
      e.stopPropagation();
      $("html,body").animate(
        {
          scrollTop: "0",
        },
        800
      );
    });
    //滚至指数
    $(".js_goGraph").on("click", function (e) {
      e.stopPropagation();
      var HQTop = $(".hqMain_data").offset().top;
      $("html,body").animate(
        {
          scrollTop: HQTop - 50,
        },
        800
      );
    });
    //滚至公告
    $(".js_goAnnouncement").on("click", function (e) {
      e.stopPropagation();
      var announceTop = $(".home_announceList").offset().top;
      $("html,body").animate(
        {
          scrollTop: announceTop - 50,
        },
        800
      );
    });
  },
  /** 主要指数 **/
  getHightChart: function () {
    //引入highstock
    require(["highstock"], function (highstock) {
      /* 初始化指数栏数据 */
      getListData(inds.join("_"));
      /* 初始化行情图 */
      drawOneDayChart(hq_active.attr("index"), "hq_area", "", true);
      /* 刷新数据 */
      refreshMethod();

      //切换行情指数
      $(".js_hq_tab").on("click", "td.hq_index", function () {
        $(this)
          .addClass("hq_tab_active")
          .siblings()
          .removeClass("hq_tab_active");
        hq_active = $(this);
        clearInterval(_refreshData);
        getListData(inds.join("_"));
        drawOneDayChart($(this).attr("index"), "hq_area", "", true);
        refreshMethod();
      });

      /* 每30s刷新一次行情数据 */
      var _refreshData;
      function refreshMethod() {
        _refreshData = setInterval(function () {
          getListData(inds.join("_"));
          drawOneDayChart(hq_active.attr("index"), "hq_area", "", false);
        }, 30000);
      }
    });
  },
  /** 市场数据 **/
  getMarketData: function () {
    // 数据处理
    String.prototype.num_toFixed = function (num) {
      var _this = "";
      if (Number(this)) {
        if (Number(this) === 0) {
          _this = "0";
        } else {
          _this = Number(this).toFixed(num);
        }
      } else if (this == "-") {
        _this = "0";
      } else {
        _this = this;
      }
      if (_this % 1 === 0) {
        _this = parseInt(_this);
      }
      return _this;
    };
    // 市场数据 - 数据总貌
    var $marketData = $(".js_marketData");
    if ($marketData.length) {
      var strArrData = [];
      strArrData.push('<ul class="sse_market_data_con">');
      strArrData.push(
        '<li><span class="tab_name">上市公司/家</span> <span class="tab_data" >' +
        home_sjtj.companyNumber +
        "</span></li>"
      );
      strArrData.push(
        '<li><span class="tab_name">上市股票/只</span> <span class="tab_data" >' +
        home_sjtj.stockNumber +
        "</span></li>"
      );
      strArrData.push(
        '<li><span class="tab_name">总股本/亿股（份）</span> <span class="tab_data" >' +
        home_sjtj.iss_vol.num_toFixed(2) +
        "</span></li>"
      );
      strArrData.push(
        '<li><span class="tab_name">流通股本/亿股（份）</span> <span class="tab_data" >' +
        home_sjtj.ngt_vol.num_toFixed(2) +
        "</span></li>"
      );
      strArrData.push(
        '<li><span class="tab_name">总市值/亿元</span> <span class="tab_data" >' +
        home_sjtj.mkt_value.num_toFixed(2) +
        "</span></li>"
      );
      strArrData.push(
        '<li><span class="tab_name">流通市值/亿元</span> <span class="tab_data" >' +
        home_sjtj.negotiable_value.num_toFixed(2) +
        "</span></li>"
      );
      strArrData.push(
        '<li><span class="tab_name">平均市盈率/倍</span> <span class="tab_data" >' +
        home_sjtj.ratioOfPe.num_toFixed(2) +
        "</span></li>"
      );
      strArrData.push("</ul>");
      $marketData.html(strArrData.join(""));
    }

    // 市场数据 - 主板
    var $marketMain = $(".js_marketMain");
    if ($marketMain.length) {
      var strArrMain = [];
      strArrMain.push('<ul class="sse_market_data_con">');
      strArrMain.push(
        '<li><span class="tab_name">上市公司/家</span> <span class="tab_data" >' +
        home_sjtj_zb.companyNumber +
        "</span></li>"
      );
      strArrMain.push(
        '<li><span class="tab_name">上市股票/只</span> <span class="tab_data" >' +
        home_sjtj_zb.stockNumber +
        "</span></li>"
      );
      strArrMain.push(
        '<li><span class="tab_name">总股本/亿股（份）</span> <span class="tab_data" >' +
        home_sjtj_zb.iss_vol.num_toFixed(2) +
        "</span></li>"
      );
      strArrMain.push(
        '<li><span class="tab_name">流通股本/亿股（份）</span> <span class="tab_data" >' +
        home_sjtj_zb.ngt_vol.num_toFixed(2) +
        "</span></li>"
      );
      strArrMain.push(
        '<li><span class="tab_name">总市值/亿元</span> <span class="tab_data" >' +
        home_sjtj_zb.mkt_value.num_toFixed(2) +
        "</span></li>"
      );
      strArrMain.push(
        '<li><span class="tab_name">流通市值/亿元</span> <span class="tab_data" >' +
        home_sjtj_zb.negotiable_value.num_toFixed(2) +
        "</span></li>"
      );
      strArrMain.push(
        '<li><span class="tab_name">平均市盈率/倍</span> <span class="tab_data" >' +
        home_sjtj_zb.ratioOfPe.num_toFixed(2) +
        "</span></li>"
      );
      strArrMain.push("</ul>");
      $marketMain.html(strArrMain.join(""));
    }

    // 市场数据 - 科创板
    var $marketStar = $(".js_marketStar");
    if ($marketStar.length) {
      var strArrStar = [];
      strArrStar.push('<ul class="sse_market_data_con">');
      strArrStar.push(
        '<li><span class="tab_name">上市公司/家</span> <span class="tab_data" data-counter-time="500" data-counter-delay="50">' +
        home_sjtj_kcb.companyNumber +
        "</span></li>"
      );
      strArrStar.push(
        '<li><span class="tab_name">上市股票/只</span> <span class="tab_data" data-counter-time="500" data-counter-delay="50">' +
        home_sjtj_kcb.stockNumber +
        "</span></li>"
      );
      strArrStar.push(
        '<li><span class="tab_name">总股本/亿股（份）</span> <span class="tab_data" data-counter-time="500" data-counter-delay="50">' +
        home_sjtj_kcb.iss_vol.num_toFixed(2) +
        "</span></li>"
      );
      strArrStar.push(
        '<li><span class="tab_name">流通股本/亿股（份）</span> <span class="tab_data" data-counter-time="500" data-counter-delay="50">' +
        home_sjtj_kcb.ngt_vol.num_toFixed(2) +
        "</span></li>"
      );
      strArrStar.push(
        '<li><span class="tab_name">总市值/亿元</span> <span class="tab_data" data-counter-time="500" data-counter-delay="50">' +
        home_sjtj_kcb.mkt_value.num_toFixed(2) +
        "</span></li>"
      );
      strArrStar.push(
        '<li><span class="tab_name">流通市值/亿元</span> <span class="tab_data" data-counter-time="500" data-counter-delay="50">' +
        home_sjtj_kcb.negotiable_value.num_toFixed(2) +
        "</span></li>"
      );
      strArrStar.push(
        '<li><span class="tab_name">平均市盈率/倍</span> <span class="tab_data" data-counter-time="500" data-counter-delay="50">' +
        home_sjtj_kcb.ratioOfPe.num_toFixed(2) +
        "</span></li>"
      );
      strArrStar.push("</ul>");
      $marketStar.html(strArrStar.join(""));
    }
    $(".market_data .new_date").html(
      "数据日期：" + home_sjtj.dataStatisticDate
    );
    /** 市场数据end **/
  },
  //数据为空empty,页面显示
  messageHtml: function (type, msg) {
    var htmlArr =
      '<div class="empty_txt d-flex justify-content-center align-items-center">';
    htmlArr += '<img src="/images/' + type + '.png">';
    htmlArr += "<span>对不起<br>" + msg + "</span>";
    htmlArr += "</div>";
    return htmlArr;
  },
  //上市公司静态公告
  getStaticRecent: function () {
    $.getJSON(
      homePage.announceFileUrl + homePage.recentTypeUrl + "?v=" + Math.random(),
      function (data) {
        if (data && data.publishData) {
          var liHtm = "";
          $.each(data.publishData, function (k, v) {
            if (k < 8) {
              liHtm +=
                '<li class="list-group-item d-flex justify-content-between">';
              liHtm += '<div class="left_txtCon">';
              liHtm +=
                '<span class="com_code">' +
                (v.securityCode ? "[" + v.securityCode + "]" : "") +
                "</span>";
              liHtm +=
                '<a target="_blank">' +
                (v.bulletinClassic == "M_LC_HOLDER_BULLETIN" ||
                  v.bulletinClassic == "K_LC_HOLDER_BULLETIN"
                  ? "<em>股东自行披露</em>"
                  : "") +
                (v.bulletinTitle ? v.bulletinTitle : "") +
                "</a>";
              liHtm += "</div>";
              liHtm +=
                '<span class="text-nowrap new_date">' +
                (v.discloseDate ? v.discloseDate : "") +
                "</span>";
              liHtm += "</li>";
            }
          });
          $(".js_recentAnnounce .list-group").html(liHtm);
        } else {
          liHtm +=
            "<li>" +
            homePage.messageHtml("empty", "没有找到您要搜索的内容。") +
            "</li>";
          $(".js_recentAnnounce .list-group").html(liHtm);
        }
      }
    );
  },
  //上市公司动态公告
  getDynamicRecent: function () {
    var startArr = homePage.today_date.split("-"),
      start_date =
        Number(startArr[0]) - 3 + "-" + startArr[1] + "-" + startArr[2];
    homePage.recentAnnounceParam.START_DATE = start_date;
    var liHtm = "";
    var liHtmArray = [];
    getJSONP({
      url: homePage.recentAnnounceUrl,
      data: homePage.recentAnnounceParam,
      successCallback: function (data) {
        if (data && data.result) {
          for (var i = 0; i < data.result.length; i++) {
            $.each(data.result[i], function (k, v) {
              if (v.TITLE) {
                if (liHtmArray.length < 8) {
                  liHtmArray.push({
                    SECURITY_CODE: v.SECURITY_CODE,
                    TITLE: v.TITLE,
                    URL: v.URL,
                    SSEDATE: v.SSEDATE,
                    IS_HOLDER_DISCLOSE: v.IS_HOLDER_DISCLOSE,
                  });
                }
              }
            })
          };
          for (var j = 0; j < liHtmArray.length; j++) {
            liHtm +=
              '<li class="list-group-item d-flex justify-content-between">';
            liHtm += '<div class="left_txtCon">';
            liHtm +=
              '<span class="com_code">' +
              (liHtmArray[j].SECURITY_CODE
                ? "[" + liHtmArray[j].SECURITY_CODE + "]"
                : "") +
              "</span>";
            liHtm +=
              '<a href="' +
              staticBulletinUrl +
              (liHtmArray[j].URL ? liHtmArray[j].URL : "") +
              '" target="_blank" >' +
              (liHtmArray[j].IS_HOLDER_DISCLOSE == 1
                ? "<em>股东自行披露</em>"
                : "") +
              (liHtmArray[j].TITLE ? liHtmArray[j].TITLE : "") +
              "</a>";
            liHtm += "</div>";
            liHtm +=
              '<span class="text-nowrap new_date">' +
              (liHtmArray[j].SSEDATE ? liHtmArray[j].SSEDATE : "") +
              "</span>";
            liHtm += "</li>";
          }
          if (data.result.length == 0) {
            liHtm +=
              "<li>" +
              homePage.messageHtml("empty", "没有找到您要搜索的内容。") +
              "</li>";
          }
        } else {
          liHtm +=
            "<li>" +
            homePage.messageHtml("empty", "没有找到您要搜索的内容。") +
            "</li>";
        }
        $(".js_recentAnnounce .list-group").html(liHtm);
      },
      errCallback: function (error) {
        liHtm +=
          "<li>" +
          homePage.messageHtml("empty", "没有找到您要搜索的内容。") +
          "</li>";
        $(".js_recentAnnounce .list-group").html(liHtm);
      },
    });
  },
  //债券静态公告
  getStaticBond: function () {
    $.getJSON(
      homePage.bondAnnounceFileUrl + "?v=" + Math.random(),
      function (data) {
        if (data && data.publishData) {
          var liHtm = "";
          $.each(data.publishData, function (k, v) {
            if (k < 8) {
              liHtm +=
                '<li class="list-group-item d-flex justify-content-between">';
              liHtm += '<div class="left_txtCon">';
              liHtm +=
                '<span class="com_code">' +
                (v.securityCode ? "[" + v.securityCode + "]" : "") +
                "</span>";
              liHtm +=
                '<a  target="_blank" >' +
                (v.bulletinTitle ? v.bulletinTitle : "") +
                "</a>";
              liHtm += "</div>";
              liHtm +=
                '<span class="text-nowrap new_date">' +
                (v.discloseDate ? v.discloseDate : "") +
                "</span>";
              liHtm += "</li>";
            }
          });
          $(".js_bondAnnounce .list-group").html(liHtm);
        } else {
          liHtm +=
            "<li>" +
            homePage.messageHtml("empty", "没有找到您要搜索的内容。") +
            "</li>";
          $(".js_fundAnnounce .list-group").html(liHtm);
        }
      }
    );
  },
  //债券动态公告
  getBondAnnounce: function () {
    var liHtm = "";
    getJSONP({
      url: homePage.bondAnnounceUrl,
      data: homePage.bondAnnounceParam,
      successCallback: function (data) {
        if (data && data.result) {
          $.each(data.result, function (k, v) {
            var sseDate = v.sseDate.substring(0, 10);
            if (v.url.length > 0) {
              var index = v.url.lastIndexOf("."),
                fileType = v.url.substr(index + 1),
                url = ((fileType !== 'shtml' && fileType !== 'html' && fileType !== 'htm') ? staticBondUrl + v.url : siteUrl + v.url)
            } else {
              var url = v.url;
            }
            liHtm +=
              '<li class="list-group-item d-flex justify-content-between">';
            liHtm += '<div class="left_txtCon">';
            liHtm +=
              '<span class="com_code">' +
              (v.securityCode ? "[" + v.securityCode + "]" : "") +
              "</span>";
            liHtm +=
              '<a href="' +
              url +
              '" target="_blank" >' +
              (v.title ? v.title : "") +
              "</a>";
            liHtm += "</div>";
            liHtm +=
              '<span class="text-nowrap new_date">' +
              (sseDate ? sseDate : "") +
              "</span>";
            liHtm += "</li>";
          });
          if (data.result.length == 0) {
            liHtm +=
              "<li>" +
              homePage.messageHtml("empty", "没有找到您要搜索的内容。") +
              "</li>";
          }
        } else {
          liHtm +=
            "<li>" +
            homePage.messageHtml("empty", "没有找到您要搜索的内容。") +
            "</li>";
        }
        $(".js_bondAnnounce .list-group").html(liHtm);
      },
      errCallback: function (error) {
        liHtm +=
          "<li>" +
          homePage.messageHtml("empty", "没有找到您要搜索的内容。") +
          "</li>";
        $(".js_bondAnnounce .list-group").html(liHtm);
      },
    });
  },
  //基金静态公告
  getStaticFund: function () {
    $.getJSON(
      homePage.fundFileUrl + homePage.fundTypeUrl + "?v=" + Math.random(),
      function (data) {
        if (data && data.publishData) {
          var liHtm = "";
          $.each(data.publishData, function (k, v) {
            if (k < 8) {
              liHtm +=
                '<li class="list-group-item d-flex justify-content-between">';
              liHtm += '<div class="left_txtCon">';
              liHtm +=
                '<span class="com_code">' +
                (v.securityCode ? "[" + v.securityCode + "]" : "") +
                "</span>";
              liHtm +=
                '<a  target="_blank" >' +
                (v.bulletinTitle ? v.bulletinTitle : "") +
                "</a>";
              liHtm += "</div>";
              liHtm +=
                '<span class="text-nowrap new_date">' +
                (v.discloseDate ? v.discloseDate : "") +
                "</span>";
              liHtm += "</li>";
            }
          });
          $(".js_fundAnnounce .list-group").html(liHtm);
        } else {
          liHtm +=
            "<li>" +
            homePage.messageHtml("empty", "没有找到您要搜索的内容。") +
            "</li>";
          $(".js_fundAnnounce .list-group").html(liHtm);
        }
      }
    );
  },
  //调用基金公告
  getFundAnnounce: function () {
    var startArr = homePage.today_date.split("-"),
      start_date =
        Number(startArr[0]) - 3 + "-" + startArr[1] + "-" + startArr[2];
    homePage.fundAnnounceParam.START_DATE = start_date;
    var liHtm = "";
    getJSONP({
      url: homePage.fundAnnounceUrl,
      data: homePage.fundAnnounceParam,
      successCallback: function (data) {
        if (data && data.result) {
          $.each(data.result, function (k, v) {
            liHtm +=
              '<li class="list-group-item d-flex justify-content-between">';
            liHtm += '<div class="left_txtCon">';
            liHtm +=
              '<span class="com_code">' +
              (v.SECURITY_CODE ? "[" + v.SECURITY_CODE + "]" : "") +
              "</span>";
            liHtm +=
              '<a href="' +
              (v.URL ? v.URL : "") +
              '" target="_blank" >' +
              (v.TITLE ? v.TITLE : "") +
              "</a>";
            liHtm += "</div>";
            liHtm +=
              '<span class="text-nowrap new_date">' +
              (v.SSEDATE ? v.SSEDATE : "") +
              "</span>";
            liHtm += "</li>";
          });
          if (data.result.length == 0) {
            liHtm +=
              "<li>" +
              homePage.messageHtml("empty", "没有找到您要搜索的内容。") +
              "</li>";
          }
        } else {
          liHtm +=
            "<li>" +
            homePage.messageHtml("empty", "没有找到您要搜索的内容。") +
            "</li>";
        }
        $(".js_fundAnnounce .list-group").html(liHtm);
      },
      errCallback: function (error) {
        liHtm +=
          "<li>" +
          homePage.messageHtml("empty", "没有找到您要搜索的内容。") +
          "</li>";
        $(".js_fundAnnounce .list-group").html(liHtm);
      },
    });
  },
  //公告搜索框特殊字符过滤
  regReplace: function (input, replace) {
    var reg = new RegExp(replace, "g");
    return input.replace(reg, "");
  },
  //公告搜索词错误信息
  searchCheck: function (className, msg) {
    $(className + " .sse_searchAnnounceInput").addClass("sse_searchError");
    $(className + " .search_error").html(msg);
  },
  //调用上市公告接口
  toSearchRecent: function () {
    var inputVal = $(".js_recentAnnounce input").val();
    if (!inputVal) {
      homePage.searchCheck(".js_recentAnnounce", "请输入关键字/代码/名称");
      return;
    }
    inputVal = homePage.regReplace(inputVal, "证券代码或简称");
    inputVal = homePage.regReplace(inputVal, "关键字");
    /*关键词/代码/名称 逻辑处理*/
    if (inputVal && !isNaN(inputVal) && inputVal.length == 6) {
      homePage.recentAnnounceParam.SECURITY_CODE = inputVal;
      homePage.recentAnnounceParam.TITLE = "";
    } else {
      homePage.recentAnnounceParam.SECURITY_CODE = "";
      homePage.recentAnnounceParam.TITLE = inputVal;
    }
    homePage.getDynamicRecent();
  },
  //调用债券公告接口
  toSearchBond: function () {
    var bondVal = $(".js_bondAnnounce input").val();
    if (!bondVal) {
      homePage.searchCheck(".js_bondAnnounce", "请输入代码");
      return;
    }
    bondVal = homePage.regReplace(bondVal, "证券代码或简称");
    if (bondVal) {
      if (isNaN(bondVal)) {
        homePage.searchCheck(".js_bondAnnounce", "证券代码必须为6位数字");
        return;
      } else {
        if (bondVal.length != 6) {
          homePage.searchCheck(".js_bondAnnounce", "证券代码必须为6位数字");
          return;
        }
      }
    }
    // homePage.bondAnnounceParam.stockcode = bondVal
    homePage.bondAnnounceParam.securityCode = bondVal;
    homePage.getBondAnnounce();
  },
  //调用基金公告接口
  toSearchFund: function () {
    var fundVal = $(".js_fundAnnounce input").val();
    if (!fundVal) {
      homePage.searchCheck(".js_fundAnnounce", "请输入代码");
      return;
    }
    fundVal = homePage.regReplace(fundVal, "证券代码或简称");
    if (fundVal) {
      if (isNaN(fundVal)) {
        homePage.searchCheck(".js_fundAnnounce", "证券代码必须为6位数字");
        return;
      } else {
        if (fundVal.length != 6) {
          homePage.searchCheck(".js_fundAnnounce", "证券代码必须为6位数字");
          return;
        }
      }
    }
    homePage.fundAnnounceParam.SECURITY_CODE = fundVal;
    homePage.getFundAnnounce();
  },
};

homePage.init();

/* 热点动态tab切换对应更多链接修改 */
$(".js_navTabs span").on("click", function () {
  if ($(this).attr("data-value") == "js_hotnews") {
    $(".js_news_more h1 a").attr("href", "/aboutus/mediacenter/hotandd/");
  } else if ($(this).attr("data-value") == "js_news") {
    $(".js_news_more h1 a").attr("href", "/home/component/news/");
  }
});
