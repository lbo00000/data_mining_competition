脚本说明：
    --build_reward.py ：reward计算
    --selenium_run.py ：页面操作可视化
