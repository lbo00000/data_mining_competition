
class Build_Reward():

    def __init__(self):
        self.search_trigger = {
        "qq音乐": "搜索",
        "上交所": "查询",
        "中国人民银行": "高级搜索",
        "中国法律服务网": "查询",
        "中国裁判文书网": "检索",
        "中国证券投资基金业协会": "查询",
        "中国银行保险监督管理委员会": "查询",
        "交通安全综合服务管理平台": "查询",
        "企查查企业查询": "查询",
        "卫健委信用信息网_医": "查询",
        "卫健委信用信息网_护": "查询",
        "国家企业信用信息公示系统": "搜索",
        "国家统计局": "开始搜索",
        "学信网": "查询",
        "安居客": "查询",
        "巨潮资讯": "查询",
        "火车票12306": "查询",
        "猫眼电影": "检索",
        "顺丰快递查收寄标准": "查询",
        "顺丰快递查运费时效": "查询"
        }

    def clear_button(self,kv_pairs):
        res = {}
        for k,v in kv_pairs.items():
            if v['dom_type']!='按钮':
                res.update({k:v})
        return res


    def forward(self,page_name,dom_desc, operation, instruction):
        r"""
        计算点击相应网页检索条件时，操作网页获取的奖励值（reward）.

        Args:
            dom_desc (string)   : dom节点文本描述
            operation (dict)    : 预测操作序列
            instruction (dict)  : 标签操作序列

        Reward Example(以"中国裁判文书网"为例):
            >> operation = {
                        '检索': {'dom_type': '按钮', 'value': '', 'action': '点击'},
                        '案由': {'dom_type': '导航树下拉框', 'value': '', 'action': '点击'},
                        '高级检索': {'dom_type': '按钮', 'value': '', 'action': '点击'}
                        }
            >> instruction = {
                        '检索': {'dom_type': '按钮', 'value': '', 'action': '点击'},
                        '案由': {'dom_type': '导航树下拉框', 'value': '', 'action': '点击'},
                        '民事案由': {'dom_type': '导航树下拉框选项', 'value': '', 'action': '点击'},
                        '高级检索': {'dom_type': '按钮', 'value': '', 'action': '点击'}
                        }
            "裁判文书网”的检索条件为“检索”，触发reward计算
            缺少对”民事案由“节点的操作，预测有误，reward, done = 0, False

        Return:
            reward (float)：奖励值（0或1）
            done (bool)：指令任务是否完成（True或False)
        """
        reward, done = 0, False
        trigger = self.search_trigger[page_name]
        if dom_desc==trigger and dom_desc in instruction :
            """
            不同网页，触发reward计算的条件说明:
                1.qq音乐:点击"搜索"按钮; 2.上交所:点击"查询"按钮; 3.中国人民银行:点击"高级搜索"按钮; 4.中国法律服务网:点击"查询"按钮; 
                5.中国裁判文书网:点击"高级检索-检索"按钮; 6.中国证券投资基金业协会:点击"查询"按钮; 7.中国银行保险监督管理委员会:点击"查询"按钮; 
                8.交通安全综合服务管理平台:点击"查询"按钮; 9.企查查企业查询:点击"查询"按钮; 10.卫健委信用信息网-医:点击"查询"按钮; 
                11.卫健委信用信息网-护:点击"查询"按钮; 12.国家企业信用信息公示系统:点击"搜索"按钮; 13.国家统计局:点击"开始搜索"按钮; 
                14.学信网:点击"查询"按钮; 15.安居客:点击"查询"按钮; 16.巨潮资讯:点击"查询"按钮; 17.火车票12306:点击"查询"按钮; 
                18.猫眼电影:点击"检索"按钮; 19.顺丰快递查收寄标准:点击"查询"按钮; 20.顺丰查运费时效:点击"查询"按钮;

            """

            #除了按钮之外的其余操作一致
            if self.clear_button(operation)==self.clear_button(instruction):
                reward, done = 1, True

        return reward, done



if __name__ == '__main__':
    build_reward = Build_Reward()

    operation = {'高级检索': {'dom_type': '下拉框', 'value': ''},
                 '案件类型': {'dom_type': '下拉框', 'value': ''},
                 '民事案件': {'dom_type': '下拉框选项', 'value': ''},
                 '检索': {'dom_type': '按钮', 'value': ''}}
    instruction = {'高级检索': {'dom_type': '下拉框', 'value': ''},
                  '全文检索': {'dom_type': '输入框', 'value': '新东信有限责任公司'},
                  '案件类型': {'dom_type': '下拉框', 'value': '民事案件'},
                  '案例等级': {'dom_type': '下拉框', 'value': ['指导性案例', '优秀文书']},
                  '检索': {'dom_type': '按钮', 'value': ''}}

    reward, done = Build_Reward().forward("中国裁判文书网","检索", operation, instruction)
    print(f"reward: {reward}")
    print(f"done: {done}")







