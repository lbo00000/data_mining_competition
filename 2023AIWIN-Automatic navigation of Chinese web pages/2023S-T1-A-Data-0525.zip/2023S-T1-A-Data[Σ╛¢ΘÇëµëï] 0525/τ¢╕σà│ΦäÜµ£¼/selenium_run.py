import io

from selenium import webdriver
from selenium.common.exceptions import TimeoutException
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.common.action_chains import ActionChains
from selenium.webdriver.common.desired_capabilities import DesiredCapabilities
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.chrome.service import Service

import PIL


class MiniWoBInstance:
    """
    Interface to interact with a selenium broswer instance
    """

    WINDOW_WIDTH = 500
    WINDOW_HEIGHT = 240
    TASK_WIDTH = 160
    TASK_HEIGHT = 210

    def __init__(
            self, url,
            wait_ms=0., block_on_reset=True, refresh_freq=0
            ):
        """
        E.g. url='file:///h/sheng/DOM-Q-NET/miniwob/html/miniwob/',
        Args:
            wait_ms: pause the instance after each action for this ms
            block_on_reset: On reset, block until the page loads
            refresh_freq: Every this # episodes, refresh the page at the begin
                          of the next episode
        http://guppy7:8000/miniwob/
        """
        super(MiniWoBInstance, self).__init__()
        print("Opening MiniWoB")

        chrome_options = Options()
        chrome_options.add_argument('--no-sandbox')
        # chrome_options.add_argument("--headless")
        # chrome_options.add_argument('--disable-gpu')
        # chrome_options.add_argument('--disable-dev-shm-usage')

        self._url = url
        ser = Service(r"/Users/collins/Documents/工作/chromedriver/chromedriver")
        self._driver = webdriver.Chrome(service=ser, options=chrome_options)
        self._driver.get(url)
        print("Chrome Task title: " + self._driver.title)


        self.WOB_REWARD_GLOBAL = 0
        self.WOB_RAW_REWARD_GLOBAL = 0
        self.WOB_REWARD_REASON = None
        self.WOB_DONE_GLOBAL = False
        self.WOB_EPISODE_ID = 0

    # def __del__(self):
    #     print("Closing MiniWoB")
    #     self._driver.quit()

    @property
    def rawhtml(self):
        js = "return document.all[0].outerHTML"
        rawhtml = self._driver.execute_script(js)
        return rawhtml

    @property
    def pagehtml(self):
        pagehtml = self._driver.page_source
        return pagehtml


    @property
    def img(self):
        png_data = self._driver.get_screenshot_as_png()
        png_data = io.BytesIO(png_data)
        pil_img = PIL.Image.open(png_data)
        img_size = pil_img.size
        pil_img = pil_img.crop(
            (0, 0, self.TASK_WIDTH, self.TASK_HEIGHT)
        ).convert('RGB')
        return pil_img, img_size


    def coord_click(self, left, top):
        body = self._driver.find_element_by_tag_name('body')
        chain = ActionChains(self._driver)
        chain.move_to_element_with_offset(body, left, top).click().perform()


    def dom_click(self, ref, fail_hard=False):
        try:
            result = self._driver.execute_script(
                'return document.all[{}].click()'.format(ref)
            )
            if not result:
                result = self._driver.execute_script(
                    'return document.all[{}].focus()'.format(ref)
                )
            if not result:
                if fail_hard:
                    raise RuntimeError()
                else:
                    pass
        except:
            pass

    def type(self, ref, text):
        # TODO WHY WOULD CLICK PAD TOKEN????
        # chain = ActionChains(self._driver)
        # chain.send_keys(text)
        # chain.perform()
        # if text == "<pad>":
        #     ipdb.set_trace()
        try:
            self._driver.execute_script(
                'return document.all[{}].value="{}"'.format(ref, text)
            )
        except:
            pass

    def focus_and_type(self, ref, text):
        self.dom_click(ref)
        self.type(ref, text)


if __name__ == '__main__':
    #需要先对目标网页进行DOM解析，以对应元素和索引号
    #然后以索引号，对节点进行“点击”、“输入”操作“
    #运行代码后会在浏览器展示
    instance = MiniWoBInstance(r"file:///E:/AIWIN/tmp/中国裁判文书网/首页.html")
    dom_index_1 = 143       #给出DOM元素的索引，在“裁判文书网”中序号为143的节点是“高级检索“
    instance.dom_click(dom_index_1)  #点击”高级检索“

    dom_index_2 = 156   # 在“裁判文书网”中序号为145的节点是“全文检索”
    text = "上海金融集团"   #待输入文字
    instance.focus_and_type(145, text)  #在“全文检索”输入框中输入文字


